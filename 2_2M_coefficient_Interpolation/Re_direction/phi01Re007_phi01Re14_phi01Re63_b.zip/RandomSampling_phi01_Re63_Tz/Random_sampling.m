close all; clear all; clc
 
 
delta_Tz_MPP1_a=load('delta_Tz_MPP1.txt');
delta_Tz_MPP2_a=load('delta_Tz_MPP2.txt');
delta_Tz_MPP3_a=load('delta_Tz_MPP3.txt');
delta_Tz_MPP4_a=load('delta_Tz_MPP4.txt');
delta_Tz_MPP5_a=load('delta_Tz_MPP5.txt');
 
delta_Tz_MPP1_N=numel(delta_Tz_MPP1_a(:,1)); %�������˳��
delta_Tz_MPP2_N=numel(delta_Tz_MPP2_a(:,1));
delta_Tz_MPP3_N=numel(delta_Tz_MPP3_a(:,1));
delta_Tz_MPP4_N=numel(delta_Tz_MPP4_a(:,1));
delta_Tz_MPP5_N=numel(delta_Tz_MPP5_a(:,1));
 
a1=randperm(delta_Tz_MPP1_N, 400);
a2=randperm(delta_Tz_MPP2_N, 400);
a3=randperm(delta_Tz_MPP3_N, 400);
a4=randperm(delta_Tz_MPP4_N, 400);
a5=randperm(delta_Tz_MPP5_N, 400);
 
%delta_Tz_MPP1_sub=delta_Tz_MPP1_a(randperm(delta_Tz_MPP1_N, 400),:);
%delta_Tz_MPP2_sub=delta_Tz_MPP2_a(randperm(delta_Tz_MPP2_N, 400),:);
%delta_Tz_MPP3_sub=delta_Tz_MPP3_a(randperm(delta_Tz_MPP3_N, 400),:);
%delta_Tz_MPP4_sub=delta_Tz_MPP4_a(randperm(delta_Tz_MPP4_N, 400),:);
%delta_Tz_MPP5_sub=delta_Tz_MPP5_a(randperm(delta_Tz_MPP5_N, 400),:);
delta_Tz_MPP1_sub=delta_Tz_MPP1_a(a1,:);
delta_Tz_MPP2_sub=delta_Tz_MPP2_a(a2,:);
delta_Tz_MPP3_sub=delta_Tz_MPP3_a(a3,:);
delta_Tz_MPP4_sub=delta_Tz_MPP4_a(a4,:);
delta_Tz_MPP5_sub=delta_Tz_MPP5_a(a5,:);
 
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta_Tz_iMPP_linear1_a=load('delta_Tz_iMPP_linear1.txt');
delta_Tz_iMPP_linear2_a=load('delta_Tz_iMPP_linear2.txt');
delta_Tz_iMPP_linear3_a=load('delta_Tz_iMPP_linear3.txt');
delta_Tz_iMPP_linear4_a=load('delta_Tz_iMPP_linear4.txt');
delta_Tz_iMPP_linear5_a=load('delta_Tz_iMPP_linear5.txt');
 
delta_Tz_iMPP_linear1_sub=delta_Tz_iMPP_linear1_a(a1,:);
delta_Tz_iMPP_linear2_sub=delta_Tz_iMPP_linear2_a(a2,:);
delta_Tz_iMPP_linear3_sub=delta_Tz_iMPP_linear3_a(a3,:);
delta_Tz_iMPP_linear4_sub=delta_Tz_iMPP_linear4_a(a4,:);
delta_Tz_iMPP_linear5_sub=delta_Tz_iMPP_linear5_a(a5,:);
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta_Tz_iMPP_regression1_a=load('delta_Tz_iMPP_regression1.txt');
delta_Tz_iMPP_regression2_a=load('delta_Tz_iMPP_regression2.txt');
delta_Tz_iMPP_regression3_a=load('delta_Tz_iMPP_regression3.txt');
delta_Tz_iMPP_regression4_a=load('delta_Tz_iMPP_regression4.txt');
delta_Tz_iMPP_regression5_a=load('delta_Tz_iMPP_regression5.txt');
 
delta_Tz_iMPP_regression1_sub=delta_Tz_iMPP_regression1_a(a1,:);
delta_Tz_iMPP_regression2_sub=delta_Tz_iMPP_regression2_a(a2,:);
delta_Tz_iMPP_regression3_sub=delta_Tz_iMPP_regression3_a(a3,:);
delta_Tz_iMPP_regression4_sub=delta_Tz_iMPP_regression4_a(a4,:);
delta_Tz_iMPP_regression5_sub=delta_Tz_iMPP_regression5_a(a5,:);
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta_Tz_DNS1_a=load('delta_Tz_DNS1.txt');
delta_Tz_DNS2_a=load('delta_Tz_DNS2.txt');
delta_Tz_DNS3_a=load('delta_Tz_DNS3.txt');
delta_Tz_DNS4_a=load('delta_Tz_DNS4.txt');
delta_Tz_DNS5_a=load('delta_Tz_DNS5.txt');
 
%delta_Tz_DNS1_N=numel(delta_Tz_DNS1_a(:,1)); 
%delta_Tz_DNS2_N=numel(delta_Tz_DNS2_a(:,1));
%delta_Tz_DNS3_N=numel(delta_Tz_DNS3_a(:,1));
%delta_Tz_DNS4_N=numel(delta_Tz_DNS4_a(:,1)); 
%delta_Tz_DNS5_N=numel(delta_Tz_DNS5_a(:,1));
 
delta_Tz_DNS1_sub=delta_Tz_DNS1_a(a1,:);
delta_Tz_DNS2_sub=delta_Tz_DNS2_a(a2,:);
delta_Tz_DNS3_sub=delta_Tz_DNS3_a(a3,:);
delta_Tz_DNS4_sub=delta_Tz_DNS4_a(a4,:);
delta_Tz_DNS5_sub=delta_Tz_DNS5_a(a5,:);
 
 
delta_Tz_MPP_sub= [delta_Tz_MPP1_sub;  delta_Tz_MPP2_sub;  delta_Tz_MPP3_sub;  delta_Tz_MPP4_sub;  delta_Tz_MPP5_sub];
delta_Tz_iMPP_linear_sub=[delta_Tz_iMPP_linear1_sub; delta_Tz_iMPP_linear2_sub; delta_Tz_iMPP_linear3_sub; delta_Tz_iMPP_linear4_sub; delta_Tz_iMPP_linear5_sub];
delta_Tz_iMPP_regression_sub=[delta_Tz_iMPP_regression1_sub; delta_Tz_iMPP_regression2_sub; delta_Tz_iMPP_regression3_sub; delta_Tz_iMPP_regression4_sub; delta_Tz_iMPP_regression5_sub];
delta_Tz_DNS_sub= [delta_Tz_DNS1_sub;  delta_Tz_DNS2_sub;  delta_Tz_DNS3_sub;  delta_Tz_DNS4_sub;  delta_Tz_DNS5_sub];
savefile = 'delta_Tz_sub.mat';
save(savefile, 'delta_Tz_DNS_sub', 'delta_Tz_MPP_sub', 'delta_Tz_iMPP_linear_sub','delta_Tz_iMPP_regression_sub');
 


