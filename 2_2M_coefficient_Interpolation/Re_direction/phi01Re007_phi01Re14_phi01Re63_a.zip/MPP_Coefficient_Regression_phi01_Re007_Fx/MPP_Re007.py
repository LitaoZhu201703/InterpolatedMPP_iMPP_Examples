#%reset -f array
#%matplotlib inline

import numpy as np
import pandas as pd
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split, KFold

# load dataset _______________________________________
dataset = pd.read_csv('../dataset/new_3D_Re007_phi01_M=1000',
                      header=None, delim_whitespace=True).values
X_in_phi01 = dataset[:2500, :np.size(dataset, axis=1) - 6]
Y_in_phi01 = dataset[:2500,  np.size(dataset, axis=1) - 3]
#print(Y_in_phi01)
Y_in_phi01 -= np.mean(Y_in_phi01)
#print(Y_in_phi01)
#aa = np.mean(Y_in_phi01)
#Y_in_phi01 -= aa
#Y_in_phi01 += aa
#print(Y_in_phi01)

dataset = pd.read_csv('../dataset/new_3D_Re007_phi01_M=1000',
                      header=None, delim_whitespace=True).values
X_in_phi02 = dataset[:2500, :np.size(dataset, axis=1) - 6]
Y_in_phi02 = dataset[:2500,  np.size(dataset, axis=1) - 3]
Y_in_phi02 -= np.mean(Y_in_phi02)
#print(Y_in_phi02)
#np.savetxt("Y_in_phi02", Y_in_phi02)
#aa = np.mean(Y_in_phi02)
#Y_in_phi02 -= aa
#Y_in_phi02 += aa
#print(Y_in_phi02)

dataset = pd.read_csv('../dataset/new_3D_Re007_phi01_M=1000',
                      header=None, delim_whitespace=True).values
X_in_phi04 = dataset[:2500, :np.size(dataset, axis=1) - 6]
Y_in_phi04 = dataset[:2500,  np.size(dataset, axis=1) - 3]
Y_in_phi04 -= np.mean(Y_in_phi04)
#print(Y_in_phi04)
#aa = np.mean(Y_in_phi04)
#Y_in_phi04 -= aa
#Y_in_phi04 += aa
#print(Y_in_phi04)

coord, title = 'F_x', '$ \mathrm{Re} = 0.07, \phi = 0.1 $'

num_p_incl = 20

cond_factor = 0.2

KDE_method = 'scipy'
#KDE_method = 'scikit'#核密度估计方法
bw_scipy = 1.8
n=5

kf = KFold(n_splits=n, shuffle=True) #交叉验证用于评估模型的预测性能,cross-validation
train_scores = []
test_scores = []

train_scores_regress = []
test_scores_regress = []

train_scores_linear = []
test_scores_linear = []

C_coefficients = np.zeros(2*num_p_incl,)
C_coefficients_regress=np.zeros(2*num_p_incl,)
C_coefficients_linear=np.zeros(2*num_p_incl,)

print(X_in_phi01.shape)
print(f'# of included particles: {num_p_incl} out of {int((X_in_phi01.shape[1] - 3) / 3) + 1}')
#print('________________________________________')

X_test_plot = np.zeros((0, X_in_phi01.shape[1]))
D_test_plot = np.zeros((0))
D_pred_plot = np.zeros((0))
D_pred_plot_regress = np.zeros((0))
D_pred_plot_linear = np.zeros((0))
 
# The cross-validation loop ________________________________
for train_index, test_index in kf.split(X_in_phi01):
    
    X_phi01, X_test_phi01 = X_in_phi01[train_index], X_in_phi01[test_index]
    Y_phi01, Y_test_phi01 = Y_in_phi01[train_index], Y_in_phi01[test_index]
    
    X_phi02, X_test_phi02 = X_in_phi02[train_index], X_in_phi02[test_index]
    Y_phi02, Y_test_phi02 = Y_in_phi02[train_index], Y_in_phi02[test_index]
    
    X_phi04, X_test_phi04 = X_in_phi04[train_index], X_in_phi04[test_index]
    Y_phi04, Y_test_phi04 = Y_in_phi04[train_index], Y_in_phi04[test_index]
    
    D_in_phi01 = Y_phi01
    D_in_phi02 = Y_phi02
    D_in_phi04 = Y_phi04
    #print(train_index)

    q = -1
    
    kde_phi01 = []
    kde_phi02 = []
    kde_phi04 = []

    for condition_phi01, condition_phi02, condition_phi04 in zip(
        [D_in_phi01 < -cond_factor * D_in_phi01.std(), D_in_phi01 > +cond_factor * D_in_phi01.std()],
        [D_in_phi02 < -cond_factor * D_in_phi02.std(), D_in_phi02 > +cond_factor * D_in_phi02.std()],
        #[D_in_phi01 < -cond_factor * D_in_phi01.std(), D_in_phi01 > +cond_factor * D_in_phi01.std()],
        [D_in_phi04 < -cond_factor * D_in_phi04.std(), D_in_phi04 > +cond_factor * D_in_phi04.std()],):
        
        # Constructing KDEs __________________________________________________
        q += 1
        
        # KDE for ϕ = 0.1 __________________________________________________
        X1_tmp = np.array([])
        X2_tmp = np.array([])
        X3_tmp = np.array([])

        for p in range(0, num_p_incl):
            X1, X2, X3 = X_phi01[:, 3*p], X_phi01[:, 3*p+1], X_phi01[:, 3*p+2]
            X1_tmp = np.append(X1_tmp, X1[condition_phi01])
            X2_tmp = np.append(X2_tmp, X2[condition_phi01])
            X3_tmp = np.append(X3_tmp, X3[condition_phi01])
        
        data = np.vstack([X1_tmp, X2_tmp, X3_tmp])

        from scipy.stats import gaussian_kde
        kde_phi01.append(gaussian_kde(data))
        bw = bw_scipy * kde_phi01[q].scotts_factor()
        kde_phi01[q].set_bandwidth(bw)
        
        # KDE for ϕ = 0.2 __________________________________________________
        X1_tmp = np.array([])
        X2_tmp = np.array([])
        X3_tmp = np.array([])

        for p in range(0, num_p_incl):
            #X1, X2, X3 = X_phi01[:, 3*p], X_phi01[:, 3*p+1], X_phi01[:, 3*p+2]##############
            X1, X2, X3 = X_phi02[:, 3*p], X_phi02[:, 3*p+1], X_phi02[:, 3*p+2]##############
            X1_tmp = np.append(X1_tmp, X1[condition_phi02])
            X2_tmp = np.append(X2_tmp, X2[condition_phi02])
            X3_tmp = np.append(X3_tmp, X3[condition_phi02])
        
        data = np.vstack([X1_tmp, X2_tmp, X3_tmp])
        
        from scipy.stats import gaussian_kde
        kde_phi02.append(gaussian_kde(data))
        bw = bw_scipy * kde_phi02[q].scotts_factor()
        kde_phi02[q].set_bandwidth(bw)
        
        # KDE for ϕ = 0.4 __________________________________________________
        X1_tmp = np.array([])
        X2_tmp = np.array([])
        X3_tmp = np.array([])

        for p in range(0, num_p_incl):
            X1, X2, X3 = X_phi04[:, 3*p], X_phi04[:, 3*p+1], X_phi04[:, 3*p+2]
            X1_tmp = np.append(X1_tmp, X1[condition_phi04])
            X2_tmp = np.append(X2_tmp, X2[condition_phi04])
            X3_tmp = np.append(X3_tmp, X3[condition_phi04])
        
        data = np.vstack([X1_tmp, X2_tmp, X3_tmp])
        
        from scipy.stats import gaussian_kde
        kde_phi04.append(gaussian_kde(data))
        bw = bw_scipy * kde_phi04[q].scotts_factor()
        kde_phi04[q].set_bandwidth(bw)
            
    # Constructing input variables ____________________________
    F_l = np.zeros((X_phi01.shape[0], 0))
    F_h = np.zeros((X_phi01.shape[0], 0))
    
    for j in range(0, num_p_incl):
#         F_l = np.append(F_l, 0.5 * (
#             kde_phi01[0]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ]) +\
#             kde_phi04[0]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ])
#                              ).reshape(-1,1), axis=1)
#         F_h = np.append(F_h, 0.5 * (
#             kde_phi01[1]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ]) +\
#             kde_phi04[1]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ])
#                              ).reshape(-1,1), axis=1)
        
        F_l = np.append(F_l, kde_phi02[0]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ]).reshape(-1,1), axis=1)
        F_h = np.append(F_h, kde_phi02[1]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ]).reshape(-1,1), axis=1)
    
    V_in_phi02 = X_phi02[:, -3:]
    
    #X_in_reg = np.hstack((F_l, F_h, V_in_phi02))
    X_in_reg = np.hstack((F_l, F_h))
    
    
    # Linear model __________________________________________________
    from sklearn.linear_model import LinearRegression
    reg = LinearRegression(normalize=False, fit_intercept=False)
       
    reg.fit(X_in_reg, D_in_phi02)
    D_pred_phi02 = reg.predict(X_in_reg)
    #print(reg.coef_)
    #print(X_in_reg)
    #print(X_in_reg.shape)
    #print(D_in_phi02)
    #print(D_in_phi02.shape)
    
    print('MPP_______________________________________')
    print(f'Training R^2\t= {r2_score(D_in_phi02, D_pred_phi02):.4f}')
    train_scores.append(r2_score(D_in_phi02, D_pred_phi02))
    
    # Testing _______________________________________________________________
    X = X_test_phi02
    
    F_l = np.zeros((X.shape[0], 0))
    F_h = np.zeros((X.shape[0], 0))

    for j in range(0, num_p_incl):
#         F_l = np.append(F_l, 0.5 * (
#             kde_phi01[0]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ]) +\
#             kde_phi04[0]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ])
#                              ).reshape(-1,1), axis=1)
#         F_h = np.append(F_h, 0.5 * (
#             kde_phi01[1]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ]) +\
#             kde_phi04[1]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ])
#                              ).reshape(-1,1), axis=1)

        F_l = np.append(F_l, kde_phi02[0]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ]).reshape(-1,1), axis=1)
        F_h = np.append(F_h, kde_phi02[1]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ]).reshape(-1,1), axis=1)

    V_in_phi02 = X[:, -3:]
    
    #X_in_reg = np.hstack((F_l, F_h, V_in_phi02))
    X_in_reg = np.hstack((F_l, F_h))
    #print(X_in_reg.shape)
    
    D_pred_test = reg.predict(X_in_reg)
    
    ##########################################################################2M_Regression
    C_coefficients_Regress = np.loadtxt('C_coefficients_Regress.txt')
    C_coefficients_linear = np.loadtxt('C_coefficients_Linear.txt')
    D_pred_test_regress=np.sum(X_in_reg*C_coefficients_Regress, axis=1)
    D_pred_test_linear=np.sum(X_in_reg*C_coefficients_linear, axis=1)
    #print(D_pred_test_2M.shape)
    #print(D_pred_test.shape)
        
    print(f'Test R^2 \t= {r2_score(Y_test_phi02, D_pred_test):.4f}')
    test_scores.append(r2_score(Y_test_phi02, D_pred_test))
    
    print('2M_Regression')
    print(f'Test_regress R^2 \t= {r2_score(Y_test_phi02, D_pred_test_regress):.4f}')
    test_scores_regress.append(r2_score(Y_test_phi02, D_pred_test_regress))
    
    print(f'Test_linear R^2 \t= {r2_score(Y_test_phi02, D_pred_test_linear):.4f}\n')
    test_scores_linear.append(r2_score(Y_test_phi02, D_pred_test_linear))
    
    # dataset for plotting all the tests together
    X_test_plot = np.vstack((X_test_plot, X_test_phi02))
    D_test_plot = np.concatenate((D_test_plot, Y_test_phi02))
    D_pred_plot = np.concatenate((D_pred_plot, D_pred_test))
    D_pred_plot_regress = np.concatenate((D_pred_plot_regress, D_pred_test_regress))
    D_pred_plot_linear = np.concatenate((D_pred_plot_linear, D_pred_test_linear))       
    
    #C_coefficients.append(reg.coef_)
    C_coefficients += reg.coef_
    
np.savetxt("delta_Fx_DNS", D_test_plot)
np.savetxt("delta_Fx_MPP", D_pred_plot)
np.savetxt("delta_Fx_iMPP_regression", D_pred_plot_regress)
np.savetxt("delta_Fx_iMPP_linear", D_pred_plot_linear)
    
C_coefficients=C_coefficients/n
np.savetxt("C_coefficients", C_coefficients)
print('Averaging C_coefficients________________________________________')    
print(C_coefficients)  

print('Averaging prediction performance________________________________________')
print(f'<Training_MPP R^2> = {np.mean(train_scores):.4f}')
print(f'<Test_MPP R^2> = {np.mean(test_scores):.4f}\n')

#print(f'<Training_regress R^2> = {np.mean(train_scores_regress):.4f}')
print(f'<Test_regress R^2> = {np.mean(test_scores_regress):.4f}')

#print(f'<Training_regress R^2> = {np.mean(train_scores_regress):.4f}')
print(f'<Test_linear R^2> = {np.mean(test_scores_linear):.4f}')


#******************************************************************************
#******************************************************************************
def plot_PDF(x1, x2, ff, title=None, savefig=True):
    '''
    This function plots the contour of the PDFs according to a
    meshgrid and values of contour.
    '''
    
    # Plot using stats KDE _________________________________________
    fig, ax1 = plt.subplots(figsize=(4, 4), tight_layout=True)
    
    mid_plane = int(grid_n.imag / 2)
    
    contour = ax1.contourf(x1[:, :, mid_plane], x2[:, :, mid_plane],
                            np.reshape(ff, x1.shape)[:, :, mid_plane],
                            cmap='jet',
                            levels=np.linspace(0, ff.max(), 20), extend='both',
                            zorder=0)

#     contour = ax1.contourf(x1[mid_plane, :, :], x2[mid_plane, :, :],
#                             np.reshape(ff, x1.shape)[mid_plane, :, :],
#                             cmap='jet',
#                             levels=np.linspace(0, ff.max(), 30), extend='both',
#                             zorder=0)

    circ1 = plt.Circle((0,0), radius=0.5,
                       alpha=1,
                       facecolor='none',
                       edgecolor='black',
                       linewidth=2,
                       zorder=2)
    ax1.add_patch(circ1)

    ax1.set_aspect('equal')

    ax1.set_xticks(range(-4,5,1))
    ax1.set_yticks(range(-4,5,1))

    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator)
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=4)

    ax1.set_xlabel('$ x $')
    ax1.set_ylabel('$ y $')
    
    if title != None:
        ax1.set_title(title, fontsize=20)
        
#         ax1.set_title(r'$ \tilde{p} \left( \cup_{j=1}^' +\
#                       f'{num_p_incl}' +\
#                       r'\mathbf{r}_j \: \vert \: \Delta F_x > 0 \right) $', fontsize=17)
#         ax1.set_title(r'$ \tilde{p}_1 \left( \mathbf{r}_{' + f'{num_p_incl}' + r'} \: \vert \: \Delta T_z < -\sigma \right) $')

    ax1.vlines(x=0, ymin=yy.min(), ymax=yy.max(), color='white', linewidth=0.75, zorder=1)
    ax1.hlines(y=0, xmin=xx.min(), xmax=xx.max(), color='white', linewidth=0.75, zorder=1)

    # Color bar________________________________
    from mpl_toolkits.axes_grid1 import make_axes_locatable
    divider = make_axes_locatable(ax1)
    cax = divider.append_axes('right', size='5%', pad=0.2)
    cb = fig.colorbar(contour, cax=cax, format='%.3f', extendrect=True)

    from matplotlib.ticker import FormatStrFormatter
    cb.ax.tick_params(labelsize=14)

    for l in cb.ax.yaxis.get_ticklabels():
        l.set_family('Times New Roman')

    # Set the font name for axis tick labels______________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')

    # remove white lines separating the contours_______________
    for c in contour.collections:
        c.set_edgecolor('face')

    # Adjust number of ticks in colorbar
    from matplotlib import ticker
    tick_locator = ticker.MaxNLocator(nbins=6)
    cb.locator = tick_locator
    cb.update_ticks()
    
    if savefig:
        fig.savefig('Fx_phi01_Re007_Original-1.pdf', bbox_inches='tight')#######################################

#Visual comparison between true and interpolated PDFs for  𝜙=0.2
import matplotlib.pyplot as plt
levels = 20
lim = 4

grid_n = 30j

xx, yy, zz = np.mgrid[-lim:lim:grid_n, -lim:lim:grid_n, -lim:lim:grid_n]
mesh = np.vstack([xx.flatten(), yy.flatten(), zz.flatten()])

ff = np.reshape(kde_phi02[1](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.01 & 0.1 $', savefig=True)
plot_PDF(xx, yy, ff, savefig=True)







#******************************************************************************
#******************************************************************************
def plot_PDF(x1, x2, ff, title=None, savefig=True):
    '''
    This function plots the contour of the PDFs according to a
    meshgrid and values of contour.
    '''
    
    # Plot using stats KDE _________________________________________
    fig, ax1 = plt.subplots(figsize=(4, 4), tight_layout=True)
    
    mid_plane = int(grid_n.imag / 2)
    
    contour = ax1.contourf(x1[:, :, mid_plane], x2[:, :, mid_plane],
                            np.reshape(ff, x1.shape)[:, :, mid_plane],
                            cmap='jet',
                            levels=np.linspace(0, ff.max(), 20), extend='both',
                            zorder=0)

#     contour = ax1.contourf(x1[mid_plane, :, :], x2[mid_plane, :, :],
#                             np.reshape(ff, x1.shape)[mid_plane, :, :],
#                             cmap='jet',
#                             levels=np.linspace(0, ff.max(), 30), extend='both',
#                             zorder=0)

    circ1 = plt.Circle((0,0), radius=0.5,
                       alpha=1,
                       facecolor='none',
                       edgecolor='black',
                       linewidth=2,
                       zorder=2)
    ax1.add_patch(circ1)

    ax1.set_aspect('equal')

    ax1.set_xticks(range(-4,5,1))
    ax1.set_yticks(range(-4,5,1))

    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator)
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=4)

    ax1.set_xlabel('$ x $')
    ax1.set_ylabel('$ y $')
    
    if title != None:
        ax1.set_title(title, fontsize=20)
        
#         ax1.set_title(r'$ \tilde{p} \left( \cup_{j=1}^' +\
#                       f'{num_p_incl}' +\
#                       r'\mathbf{r}_j \: \vert \: \Delta F_x > 0 \right) $', fontsize=17)
#         ax1.set_title(r'$ \tilde{p}_1 \left( \mathbf{r}_{' + f'{num_p_incl}' + r'} \: \vert \: \Delta T_z < -\sigma \right) $')

    ax1.vlines(x=0, ymin=yy.min(), ymax=yy.max(), color='white', linewidth=0.75, zorder=1)
    ax1.hlines(y=0, xmin=xx.min(), xmax=xx.max(), color='white', linewidth=0.75, zorder=1)

    # Color bar________________________________
    from mpl_toolkits.axes_grid1 import make_axes_locatable
    divider = make_axes_locatable(ax1)
    cax = divider.append_axes('right', size='5%', pad=0.2)
    cb = fig.colorbar(contour, cax=cax, format='%.3f', extendrect=True)

    from matplotlib.ticker import FormatStrFormatter
    cb.ax.tick_params(labelsize=14)

    for l in cb.ax.yaxis.get_ticklabels():
        l.set_family('Times New Roman')

    # Set the font name for axis tick labels______________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')

    # remove white lines separating the contours_______________
    for c in contour.collections:
        c.set_edgecolor('face')

    # Adjust number of ticks in colorbar
    from matplotlib import ticker
    tick_locator = ticker.MaxNLocator(nbins=6)
    cb.locator = tick_locator
    cb.update_ticks()
    
    if savefig:
        fig.savefig('Fx_phi01_Re007_Original_0.pdf', bbox_inches='tight')#################################

#Visual comparison between true and interpolated PDFs for  𝜙=0.2
import matplotlib.pyplot as plt
levels = 20
lim = 4

grid_n = 30j

xx, yy, zz = np.mgrid[-lim:lim:grid_n, -lim:lim:grid_n, -lim:lim:grid_n]
mesh = np.vstack([xx.flatten(), yy.flatten(), zz.flatten()])

ff = np.reshape(kde_phi02[0](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi =  0.01 & 0.1 $', savefig=True)
plot_PDF(xx, yy, ff, savefig=True)

#ff = np.reshape(kde_phi02[1](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.07 $')
#plot_PDF(xx, yy, ff, title='$ \phi = 0.01 & 0.1 $', savefig=True)

#ff = np.reshape(kde_phi04[1](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.1 $', savefig=True)

#ff = np.reshape(kde_phi01[0](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.01 $', savefig=True)

#ff = np.reshape(kde_phi02[0](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.07 $')
#plot_PDF(xx, yy, ff, title='$ \phi = 0.01 & 0.1 $', savefig=True)

#ff = np.reshape(kde_phi04[0](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.1 $', savefig=True)

#******************************************************************************


# plotting _______________________________________________________________________MPP-iMPP-Regress
def plot_regression(D_in, D_pred, coord=None, title=None, save_fig=True):
    
    plt.rcParams['xtick.labelsize'] = 16
    plt.rcParams['ytick.labelsize'] = 16
    plt.rcParams['axes.labelsize'] = 22
    plt.rcParams['axes.titlesize'] = 14

    # generate the best fit for the predicted data ___________________
    lim1 = np.mean(D_in) - 3.5*np.std(D_in)
    lim2 = np.mean(D_in) + 3.5*np.std(D_in)
    lim3 = np.mean(D_pred) - 2*np.std(D_pred)

    reg2 = LinearRegression()
    reg2.fit(D_in.reshape(-1,1), D_pred.reshape(-1,1))
    D_vec = np.linspace(lim1, lim2, 100).reshape(-1,1)
    D_reg2 = reg2.predict(D_vec)
    
    # Plots _____________________
    fig, ax1 = plt.subplots(figsize=(4,4), tight_layout=True)
    
    ax1.scatter(D_in, D_pred,
                marker='o',
                s=10, linewidth=0.4,
                alpha=0.5,
                edgecolor='blue', facecolor='white')
    ax1.plot([lim1, lim2], [lim1, lim2], linestyle='-', color='red', linewidth=2.5, alpha=0.3)
#     ax1.plot(D_vec, D_reg2, linestyle='-', color='black', linewidth=2.5, alpha=0.1)
    
    ax1.set_aspect('equal')
    
    if coord != None:
        if coord == 'F_x':
            ax1.set_xlabel('$\Delta F_{x,MPP}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{x,iMPP-Regress}$', labelpad=10)
        elif coord == 'F_y':
            ax1.set_xlabel('$\Delta F_{y,MPP}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{y,iMPP-Regress}$', labelpad=10)
        elif coord == 'T_z':
            ax1.set_xlabel('$\Delta T_{z,MPP}$', labelpad=15)
            ax1.set_ylabel('$\Delta T_{z,iMPP-Regress}$', labelpad=10)
    
    ax1.set_xlim((1.0*lim1, 1.0*lim2))
    ax1.set_ylim((1.0*lim1, 1.0*lim2))

    #     ax1.set_xticks(range(-4,5,1))
    #     ax1.set_yticks(range(-4,5,1))

    # R^2 on plot _____________________
    x_ann = ax1.get_xlim()[1] - 0.05*(plt.xlim()[1]-plt.xlim()[0])
    y_ann = ax1.get_ylim()[0] + 0.05*(plt.ylim()[1]-plt.ylim()[0])
    ax1.annotate(str(r'$\mathrm{R^2} = ' + f'{r2_score(D_in, D_pred):.4f}$'), 
                 xy=(x_ann, y_ann),
                 horizontalalignment='right',
                 verticalalignment='bottom',
                 fontsize=18);

    # ticks _____________________
    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator, MaxNLocator)
    
    ax1.xaxis.set_major_locator(MaxNLocator(5))
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.yaxis.set_major_locator(MaxNLocator(5))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=2)
    
    # Set the font name for axis tick labels _____________________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')
        
    if title != None:
        ax1.set_title(title)
        
    if save_fig:
        fig.savefig('R2_Fx_phi01_Re007_iMPP-regress.pdf', bbox_inches='tight')########################################
    
    return None

#plot_regression(coord=coord, title=title, save_fig=True)
import matplotlib.pyplot as plt
plot_regression(D_in=D_pred_plot, D_pred=D_pred_plot_regress, coord=coord, title=title, save_fig=True)

#*****************************************************************************
#Coefficients

#plt.plot(reg.coef_, linewidth=0, marker='.', color='red', markersize=10)
#plt.grid()



# plotting _______________________________________________________________________MPP-iMPP-Linear
def plot_regression(D_in, D_pred, coord=None, title=None, save_fig=True):
    
    plt.rcParams['xtick.labelsize'] = 16
    plt.rcParams['ytick.labelsize'] = 16
    plt.rcParams['axes.labelsize'] = 22
    plt.rcParams['axes.titlesize'] = 14

    # generate the best fit for the predicted data ___________________
    lim1 = np.mean(D_in) - 3.5*np.std(D_in)
    lim2 = np.mean(D_in) + 3.5*np.std(D_in)
    lim3 = np.mean(D_pred) - 2*np.std(D_pred)

    reg2 = LinearRegression()
    reg2.fit(D_in.reshape(-1,1), D_pred.reshape(-1,1))
    D_vec = np.linspace(lim1, lim2, 100).reshape(-1,1)
    D_reg2 = reg2.predict(D_vec)
    
    # Plots _____________________
    fig, ax1 = plt.subplots(figsize=(4,4), tight_layout=True)
    
    ax1.scatter(D_in, D_pred,
                marker='o',
                s=10, linewidth=0.4,
                alpha=0.5,
                edgecolor='blue', facecolor='white')
    ax1.plot([lim1, lim2], [lim1, lim2], linestyle='-', color='red', linewidth=2.5, alpha=0.3)
#     ax1.plot(D_vec, D_reg2, linestyle='-', color='black', linewidth=2.5, alpha=0.1)
    
    ax1.set_aspect('equal')
    
    if coord != None:
        if coord == 'F_x':
            ax1.set_xlabel('$\Delta F_{x,MPP}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{x,iMPP-linear}$', labelpad=10)
        elif coord == 'F_y':
            ax1.set_xlabel('$\Delta F_{y,MPP}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{y,iMPP-linear}$', labelpad=10)
        elif coord == 'T_z':
            ax1.set_xlabel('$\Delta T_{z,MPP}$', labelpad=15)
            ax1.set_ylabel('$\Delta T_{z,iMPP-linear}$', labelpad=10)
    
    ax1.set_xlim((1.0*lim1, 1.0*lim2))
    ax1.set_ylim((1.0*lim1, 1.0*lim2))

    #     ax1.set_xticks(range(-4,5,1))
    #     ax1.set_yticks(range(-4,5,1))

    # R^2 on plot _____________________
    x_ann = ax1.get_xlim()[1] - 0.05*(plt.xlim()[1]-plt.xlim()[0])
    y_ann = ax1.get_ylim()[0] + 0.05*(plt.ylim()[1]-plt.ylim()[0])
    ax1.annotate(str(r'$\mathrm{R^2} = ' + f'{r2_score(D_in, D_pred):.4f}$'), 
                 xy=(x_ann, y_ann),
                 horizontalalignment='right',
                 verticalalignment='bottom',
                 fontsize=18);

    # ticks _____________________
    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator, MaxNLocator)
    
    ax1.xaxis.set_major_locator(MaxNLocator(5))
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.yaxis.set_major_locator(MaxNLocator(5))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=2)
    
    # Set the font name for axis tick labels _____________________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')
        
    if title != None:
        ax1.set_title(title)
        
    if save_fig:
        fig.savefig('R2_Fx_phi01_Re007_iMPP-linear.pdf', bbox_inches='tight')#####################
    
    return None

#plot_regression(coord=coord, title=title, save_fig=True)
import matplotlib.pyplot as plt
plot_regression(D_in=D_pred_plot, D_pred=D_pred_plot_linear, coord=coord, title=title, save_fig=True)

#*****************************************************************************



# plotting _______________________________________________________________________DNS-MPP
def plot_regression(D_in, D_pred, coord=None, title=None, save_fig=True):
    
    plt.rcParams['xtick.labelsize'] = 16
    plt.rcParams['ytick.labelsize'] = 16
    plt.rcParams['axes.labelsize'] = 22
    plt.rcParams['axes.titlesize'] = 14

    # generate the best fit for the predicted data ___________________
    lim1 = np.mean(D_in) - 3.5*np.std(D_in)
    lim2 = np.mean(D_in) + 3.5*np.std(D_in)
    lim3 = np.mean(D_pred) - 2*np.std(D_pred)

    reg2 = LinearRegression()
    reg2.fit(D_in.reshape(-1,1), D_pred.reshape(-1,1))
    D_vec = np.linspace(lim1, lim2, 100).reshape(-1,1)
    D_reg2 = reg2.predict(D_vec)
    
    # Plots _____________________
    fig, ax1 = plt.subplots(figsize=(4,4), tight_layout=True)
    
    ax1.scatter(D_in, D_pred,
                marker='o',
                s=10, linewidth=0.4,
                alpha=0.5,
                edgecolor='blue', facecolor='white')
    ax1.plot([lim1, lim2], [lim1, lim2], linestyle='-', color='red', linewidth=2.5, alpha=0.3)
#     ax1.plot(D_vec, D_reg2, linestyle='-', color='black', linewidth=2.5, alpha=0.1)
    
    ax1.set_aspect('equal')
    
    if coord != None:
        if coord == 'F_x':
            ax1.set_xlabel('$\Delta F_{x,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{x,MPP}$', labelpad=10)
        elif coord == 'F_y':
            ax1.set_xlabel('$\Delta F_{y,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{y,MPP}$', labelpad=10)
        elif coord == 'T_z':
            ax1.set_xlabel('$\Delta T_{z,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta T_{z,MPP}$', labelpad=10)
    
    ax1.set_xlim((1.0*lim1, 1.0*lim2))
    ax1.set_ylim((1.0*lim1, 1.0*lim2))

    #     ax1.set_xticks(range(-4,5,1))
    #     ax1.set_yticks(range(-4,5,1))

    # R^2 on plot _____________________
    x_ann = ax1.get_xlim()[1] - 0.05*(plt.xlim()[1]-plt.xlim()[0])
    y_ann = ax1.get_ylim()[0] + 0.05*(plt.ylim()[1]-plt.ylim()[0])
    ax1.annotate(str(r'$\mathrm{R^2} = ' + f'{r2_score(D_in, D_pred):.4f}$'), 
                 xy=(x_ann, y_ann),
                 horizontalalignment='right',
                 verticalalignment='bottom',
                 fontsize=18);

    # ticks _____________________
    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator, MaxNLocator)
    
    ax1.xaxis.set_major_locator(MaxNLocator(5))
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.yaxis.set_major_locator(MaxNLocator(5))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=2)
    
    # Set the font name for axis tick labels _____________________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')
        
    if title != None:
        ax1.set_title(title)
        
    if save_fig:
        fig.savefig('R2_Fx_phi01_Re007_MPP.pdf', bbox_inches='tight')############################
    
    return None

#plot_regression(coord=coord, title=title, save_fig=True)
import matplotlib.pyplot as plt
plot_regression(D_in=D_test_plot, D_pred=D_pred_plot, coord=coord, title=title, save_fig=True)




# plotting _______________________________________________________________________DNS-iMPP-regress
def plot_regression(D_in, D_pred, coord=None, title=None, save_fig=True):
    
    plt.rcParams['xtick.labelsize'] = 16
    plt.rcParams['ytick.labelsize'] = 16
    plt.rcParams['axes.labelsize'] = 22
    plt.rcParams['axes.titlesize'] = 14

    # generate the best fit for the predicted data ___________________
    lim1 = np.mean(D_in) - 3.5*np.std(D_in)
    lim2 = np.mean(D_in) + 3.5*np.std(D_in)
    lim3 = np.mean(D_pred) - 2*np.std(D_pred)

    reg2 = LinearRegression()
    reg2.fit(D_in.reshape(-1,1), D_pred.reshape(-1,1))
    D_vec = np.linspace(lim1, lim2, 100).reshape(-1,1)
    D_reg2 = reg2.predict(D_vec)
    
    # Plots _____________________
    fig, ax1 = plt.subplots(figsize=(4,4), tight_layout=True)
    
    ax1.scatter(D_in, D_pred,
                marker='o',
                s=10, linewidth=0.4,
                alpha=0.5,
                edgecolor='blue', facecolor='white')
    ax1.plot([lim1, lim2], [lim1, lim2], linestyle='-', color='red', linewidth=2.5, alpha=0.3)
#     ax1.plot(D_vec, D_reg2, linestyle='-', color='black', linewidth=2.5, alpha=0.1)
    
    ax1.set_aspect('equal')
    
    if coord != None:
        if coord == 'F_x':
            ax1.set_xlabel('$\Delta F_{x,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{x,iMPP-regress}$', labelpad=10)
        elif coord == 'F_y':
            ax1.set_xlabel('$\Delta F_{y,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{y,iMPP-regress}$', labelpad=10)
        elif coord == 'T_z':
            ax1.set_xlabel('$\Delta T_{z,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta T_{z,iMPP-regress}$', labelpad=10)
    
    ax1.set_xlim((1.0*lim1, 1.0*lim2))
    ax1.set_ylim((1.0*lim1, 1.0*lim2))

    #     ax1.set_xticks(range(-4,5,1))
    #     ax1.set_yticks(range(-4,5,1))

    # R^2 on plot _____________________
    x_ann = ax1.get_xlim()[1] - 0.05*(plt.xlim()[1]-plt.xlim()[0])
    y_ann = ax1.get_ylim()[0] + 0.05*(plt.ylim()[1]-plt.ylim()[0])
    ax1.annotate(str(r'$\mathrm{R^2} = ' + f'{r2_score(D_in, D_pred):.4f}$'), 
                 xy=(x_ann, y_ann),
                 horizontalalignment='right',
                 verticalalignment='bottom',
                 fontsize=18);

    # ticks _____________________
    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator, MaxNLocator)
    
    ax1.xaxis.set_major_locator(MaxNLocator(5))
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.yaxis.set_major_locator(MaxNLocator(5))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=2)
    
    # Set the font name for axis tick labels _____________________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')
        
    if title != None:
        ax1.set_title(title)
        
    if save_fig:
        fig.savefig('R2_Fx_phi01_Re007_DNS-regress.pdf', bbox_inches='tight')########################################
    
    return None

#plot_regression(coord=coord, title=title, save_fig=True)
import matplotlib.pyplot as plt
plot_regression(D_in=D_test_plot, D_pred=D_pred_plot_regress, coord=coord, title=title, save_fig=True)





# plotting _______________________________________________________________________DNS-iMPP-Linear
def plot_regression(D_in, D_pred, coord=None, title=None, save_fig=True):
    
    plt.rcParams['xtick.labelsize'] = 16
    plt.rcParams['ytick.labelsize'] = 16
    plt.rcParams['axes.labelsize'] = 22
    plt.rcParams['axes.titlesize'] = 14

    # generate the best fit for the predicted data ___________________
    lim1 = np.mean(D_in) - 3.5*np.std(D_in)
    lim2 = np.mean(D_in) + 3.5*np.std(D_in)
    lim3 = np.mean(D_pred) - 2*np.std(D_pred)

    reg2 = LinearRegression()
    reg2.fit(D_in.reshape(-1,1), D_pred.reshape(-1,1))
    D_vec = np.linspace(lim1, lim2, 100).reshape(-1,1)
    D_reg2 = reg2.predict(D_vec)
    
    # Plots _____________________
    fig, ax1 = plt.subplots(figsize=(4,4), tight_layout=True)
    
    ax1.scatter(D_in, D_pred,
                marker='o',
                s=10, linewidth=0.4,
                alpha=0.5,
                edgecolor='blue', facecolor='white')
    ax1.plot([lim1, lim2], [lim1, lim2], linestyle='-', color='red', linewidth=2.5, alpha=0.3)
#   ax1.plot(D_vec, D_reg2, linestyle='-', color='black', linewidth=2.5, alpha=0.1)
    
    ax1.set_aspect('equal')
    
    if coord != None:
        if coord == 'F_x':
            ax1.set_xlabel('$\Delta F_{x,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{x,iMPP-linear}$', labelpad=10)
        elif coord == 'F_y':
            ax1.set_xlabel('$\Delta F_{y,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{y,iMPP-linear}$', labelpad=10)
        elif coord == 'T_z':
            ax1.set_xlabel('$\Delta T_{z,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta T_{z,iMPP-linear}$', labelpad=10)
    
    ax1.set_xlim((1.0*lim1, 1.0*lim2))
    ax1.set_ylim((1.0*lim1, 1.0*lim2))

    #     ax1.set_xticks(range(-4,5,1))
    #     ax1.set_yticks(range(-4,5,1))

    # R^2 on plot _____________________
    x_ann = ax1.get_xlim()[1] - 0.05*(plt.xlim()[1]-plt.xlim()[0])
    y_ann = ax1.get_ylim()[0] + 0.05*(plt.ylim()[1]-plt.ylim()[0])
    ax1.annotate(str(r'$\mathrm{R^2} = ' + f'{r2_score(D_in, D_pred):.4f}$'), 
                 xy=(x_ann, y_ann),
                 horizontalalignment='right',
                 verticalalignment='bottom',
                 fontsize=18);

    # ticks _____________________
    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator, MaxNLocator)
    
    ax1.xaxis.set_major_locator(MaxNLocator(5))
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.yaxis.set_major_locator(MaxNLocator(5))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=2)
    
    # Set the font name for axis tick labels _____________________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')
        
    if title != None:
        ax1.set_title(title)
        
    if save_fig:
        fig.savefig('R2_Fx_phi01_Re007_DNS-linear.pdf', bbox_inches='tight')########################################
    
    return None

#plot_regression(coord=coord, title=title, save_fig=True)
import matplotlib.pyplot as plt
plot_regression(D_in=D_test_plot, D_pred=D_pred_plot_linear, coord=coord, title=title, save_fig=True)

