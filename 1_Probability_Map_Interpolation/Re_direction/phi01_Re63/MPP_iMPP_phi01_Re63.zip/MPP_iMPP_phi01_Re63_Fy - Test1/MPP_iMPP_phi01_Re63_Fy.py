#%reset -f array
#%matplotlib inline

import numpy as np
import pandas as pd
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split, KFold

# load dataset _______________________________________
dataset = pd.read_csv('../dataset/Re40_phi01',
                      header=None, delim_whitespace=True).values
X_in_phi01 = dataset[:2500, :np.size(dataset, axis=1) - 6]
Y_in_phi01 = dataset[:2500,  np.size(dataset, axis=1) - 2]
Y_in_phi01 -= np.mean(Y_in_phi01)

#############################################################
X_in_phi011 = dataset[:1250, :np.size(dataset, axis=1) - 6]
Y_in_phi011 = dataset[:1250,  np.size(dataset, axis=1) - 2]
Y_in_phi011 -= np.mean(Y_in_phi011)


dataset = pd.read_csv('../dataset/new_3D_Re63_phi01_M=1000',
                      header=None, delim_whitespace=True).values
X_in_phi02 = dataset[:2500, :np.size(dataset, axis=1) - 6]
Y_in_phi02 = dataset[:2500,  np.size(dataset, axis=1) - 2]
Y_in_phi02 -= np.mean(Y_in_phi02)
#print(X_in_phi02)


dataset = pd.read_csv('../dataset/new_3D_Re80_phi01_M=1000',
                      header=None, delim_whitespace=True).values
X_in_phi04 = dataset[:2500, :np.size(dataset, axis=1) - 6]
Y_in_phi04 = dataset[:2500,  np.size(dataset, axis=1) - 2]
Y_in_phi04 -= np.mean(Y_in_phi04)

#################################################################
X_in_phi044 = dataset[:1250, :np.size(dataset, axis=1) - 6]
Y_in_phi044 = dataset[:1250,  np.size(dataset, axis=1) - 2]
Y_in_phi044 -= np.mean(Y_in_phi044)

#################################################################
#Combining dataset
#X_in_phi=np.vstack((X_in_phi011,X_in_phi044))
#Y_in_phi=np.hstack((Y_in_phi011,Y_in_phi044))
#print(Y_in_phi.shape)
#print(X_in_phi.shape)

X_in_phi044_sub=X_in_phi044[:,:90]
print(X_in_phi044_sub.shape)

X_in_phi=np.vstack((X_in_phi011,X_in_phi044_sub))
Y_in_phi=np.hstack((Y_in_phi011,Y_in_phi044))

##########################################################################
Re1=40
Re2=63
Re3=80
a1=(Re3-Re2)/(Re3-Re1)
a2=(Re2-Re1)/(Re3-Re1)

coord, title = 'F_y', '$ \mathrm{Re} = 63, \phi = 0.1 $'#***************************************************

num_p_incl = 20

#cond_factor = 0.
cond_factor = 0.2

KDE_method = 'scipy'
#KDE_method = 'scikit'#核密度估计方法
bw_scipy = 1.8
n=5

kf = KFold(n_splits=5, shuffle=True)

##############Combined data
train_scores_iMPP_data = []
test_scores_iMPP_data = []

############Combined KDE
train_scores_iMPP_kkddee = []
test_scores_iMPP_kkddee= []

#############Original MPP
train_scores_MPP = []
test_scores_MPP = []

C_coefficients_data = np.zeros(2*num_p_incl,)
C_coefficients_kkddee = np.zeros(2*num_p_incl,)
C_coefficients_MPP = np.zeros(2*num_p_incl,)

#X_in_phi01=np.hstack((X_in_phi01,X_in_phi04))
#y_in_phi01=np.hstack((Y_in_phi01,Y_in_phi04))
print(X_in_phi01.shape)
print(f'# of included particles: {num_p_incl} out of {int((X_in_phi01.shape[1] - 3) / 3) + 1}')
#print('________________________________________')

X_test_plot = np.zeros((0, X_in_phi01.shape[1]))
#print(X_test_plot)
D_test_plot = np.zeros((0))

D_pred_plot_data = np.zeros((0))
D_pred_plot_kkddee = np.zeros((0))
D_pred_plot_MPP = np.zeros((0))


# The cross-validation loop ________________________________
for train_index, test_index in kf.split(X_in_phi01):
    
    X_phi01, X_test_phi01 = X_in_phi01[train_index], X_in_phi01[test_index]
    Y_phi01, Y_test_phi01 = Y_in_phi01[train_index], Y_in_phi01[test_index]
    
    X_phi02, X_test_phi02 = X_in_phi02[train_index], X_in_phi02[test_index]
    Y_phi02, Y_test_phi02 = Y_in_phi02[train_index], Y_in_phi02[test_index]
    
    X_phi04, X_test_phi04 = X_in_phi04[train_index], X_in_phi04[test_index]
    Y_phi04, Y_test_phi04 = Y_in_phi04[train_index], Y_in_phi04[test_index]

###############################################################################Combined data 
    X_phi, X_test_phi = X_in_phi[train_index], X_in_phi[test_index]
    Y_phi, Y_test_phi = Y_in_phi[train_index], Y_in_phi[test_index]

    #print(X_phi)
    #X_phi02=X_phi
    #X_test_phi02=X_test_phi
    
    D_in_phi01 = Y_phi01
    D_in_phi02 = Y_phi02
    #D_in_phi02 = Y_phi
    #Y_test_phi02=Y_test_phi
    D_in_phi04 = Y_phi04
    
    #print(train_index)
    #print(test_index)

    q = -1
    
    kde_phi01 = []
    kde_combined = []
    kde_phi02_MPP = []
    kde_phi04 = []

    for condition_phi01, condition_combined_data, condition_phi02_MPP, condition_phi04 in zip(
        [D_in_phi01 < -cond_factor * D_in_phi01.std(), D_in_phi01 > +cond_factor * D_in_phi01.std()],
        [Y_phi < -cond_factor * Y_phi.std(), Y_phi > +cond_factor * Y_phi.std()],
        [D_in_phi02 < -cond_factor * D_in_phi02.std(), D_in_phi02 > +cond_factor * D_in_phi02.std()],
        [D_in_phi04 < -cond_factor * D_in_phi04.std(), D_in_phi04 > +cond_factor * D_in_phi04.std()],):
        
        # Constructing KDEs ________________________________________________
        q += 1
        
        # KDE for ϕ = 0.1 __________________________________________________
        X1_tmp = np.array([])
        X2_tmp = np.array([])
        X3_tmp = np.array([])

        for p in range(0, num_p_incl):
            X1, X2, X3 = X_phi01[:, 3*p], X_phi01[:, 3*p+1], X_phi01[:, 3*p+2]
            X1_tmp = np.append(X1_tmp, X1[condition_phi01])
            X2_tmp = np.append(X2_tmp, X2[condition_phi01])
            X3_tmp = np.append(X3_tmp, X3[condition_phi01])
        
        data = np.vstack([X1_tmp, X2_tmp, X3_tmp])
        #print(data.shape)

        from scipy.stats import gaussian_kde
        kde_phi01.append(gaussian_kde(data))
        bw = bw_scipy * kde_phi01[q].scotts_factor()
        kde_phi01[q].set_bandwidth(bw)
        
        # KDE for Combined_data__________________________________________________Combined_data
        X1_tmp = np.array([])
        X2_tmp = np.array([])
        X3_tmp = np.array([])

        for p in range(0, num_p_incl):
            #X1, X2, X3 = X_phi02[:, 3*p], X_phi02[:, 3*p+1], X_phi02[:, 3*p+2]
            X1, X2, X3 = X_phi[:, 3*p], X_phi[:, 3*p+1], X_phi[:, 3*p+2]
            X1_tmp = np.append(X1_tmp, X1[condition_combined_data])
            X2_tmp = np.append(X2_tmp, X2[condition_combined_data])
            X3_tmp = np.append(X3_tmp, X3[condition_combined_data])
        
        data = np.vstack([X1_tmp, X2_tmp, X3_tmp])
        #print(data.shape)
        
        from scipy.stats import gaussian_kde
        kde_combined.append(gaussian_kde(data))
        bw = bw_scipy * kde_combined[q].scotts_factor()
        kde_combined[q].set_bandwidth(bw)
        
        
        # KDE for ϕ = 0.2________MPP__________________________________________________MPP
        X1_tmp = np.array([])
        X2_tmp = np.array([])
        X3_tmp = np.array([])

        for p in range(0, num_p_incl):
            X1, X2, X3 = X_phi02[:, 3*p], X_phi02[:, 3*p+1], X_phi02[:, 3*p+2]
            #X1, X2, X3 = X_phi[:, 3*p], X_phi[:, 3*p+1], X_phi[:, 3*p+2]
            X1_tmp = np.append(X1_tmp, X1[condition_phi02_MPP])
            X2_tmp = np.append(X2_tmp, X2[condition_phi02_MPP])
            X3_tmp = np.append(X3_tmp, X3[condition_phi02_MPP])
        
        data = np.vstack([X1_tmp, X2_tmp, X3_tmp])
        #print(data.shape)
        
        from scipy.stats import gaussian_kde
        kde_phi02_MPP.append(gaussian_kde(data))
        bw = bw_scipy * kde_phi02_MPP[q].scotts_factor()
        kde_phi02_MPP[q].set_bandwidth(bw)
        
        
        # KDE for ϕ = 0.4 __________________________________________________
        X1_tmp = np.array([])
        X2_tmp = np.array([])
        X3_tmp = np.array([])

        for p in range(0, num_p_incl):
            X1, X2, X3 = X_phi04[:, 3*p], X_phi04[:, 3*p+1], X_phi04[:, 3*p+2]
            X1_tmp = np.append(X1_tmp, X1[condition_phi04])
            X2_tmp = np.append(X2_tmp, X2[condition_phi04])
            X3_tmp = np.append(X3_tmp, X3[condition_phi04])
        
        data = np.vstack([X1_tmp, X2_tmp, X3_tmp])
        #print(data.shape)
        
        from scipy.stats import gaussian_kde
        kde_phi04.append(gaussian_kde(data))
        bw = bw_scipy * kde_phi04[q].scotts_factor()
        kde_phi04[q].set_bandwidth(bw)
            
    # Constructing input variables ____________________________
    F_l_data = np.zeros((X_phi01.shape[0], 0))
    F_h_data = np.zeros((X_phi01.shape[0], 0))
    
    F_l_kkddee = np.zeros((X_phi01.shape[0], 0))
    F_h_kkddee = np.zeros((X_phi01.shape[0], 0))
    
    F_l_MPP = np.zeros((X_phi02.shape[0], 0))#new
    F_h_MPP = np.zeros((X_phi02.shape[0], 0))#new
    
    for j in range(0, num_p_incl):
          F_l_kkddee= np.append(F_l_kkddee, (
             a1*(kde_phi01[0]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ])) +\
             a2*(kde_phi04[0]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ]))
                  ).reshape(-1,1), axis=1)
          F_h_kkddee = np.append(F_h_kkddee, (
             a1*(kde_phi01[1]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ])) +\
             a2*(kde_phi04[1]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ]))
                  ).reshape(-1,1), axis=1)
            
          F_l_data = np.append(F_l_data, kde_combined[0]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ]).reshape(-1,1), axis=1)
          F_h_data = np.append(F_h_data, kde_combined[1]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ]).reshape(-1,1), axis=1)
        
          F_l_MPP = np.append(F_l_MPP, kde_phi02_MPP[0]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ]).reshape(-1,1), axis=1)
          F_h_MPP = np.append(F_h_MPP, kde_phi02_MPP[1]([ X_phi02[:, 3*j], X_phi02[:, 3*j+1], X_phi02[:, 3*j+2] ]).reshape(-1,1), axis=1)
        #np.append，axis=1按列堆叠
    
    #V_in_phi02 = X_phi02[:, -3:]
    
    #X_in_reg = np.hstack((F_l, F_h, V_in_phi02))
    X_in_reg_data = np.hstack((F_l_data, F_h_data))
    X_in_reg_kkddee = np.hstack((F_l_kkddee, F_h_kkddee))
    X_in_reg_MPP = np.hstack((F_l_MPP, F_h_MPP))
    
    # Linear model __________________________________________________
    from sklearn.linear_model import LinearRegression
    reg_data = LinearRegression(normalize=False, fit_intercept=False)
    reg_kkddee = LinearRegression(normalize=False, fit_intercept=False)
    reg_MPP = LinearRegression(normalize=False, fit_intercept=False)
       
    reg_data.fit(X_in_reg_data, D_in_phi02)
    D_pred_phi02_data = reg_data.predict(X_in_reg_data)
    #print(reg.predict(X_in_reg))
    #print(reg.coef_)
    #print(np.size(reg.coef_))
    
    reg_kkddee.fit(X_in_reg_kkddee, D_in_phi02)
    D_pred_phi02_kkddee = reg_kkddee.predict(X_in_reg_kkddee)
    
    reg_MPP.fit(X_in_reg_MPP, D_in_phi02)
    D_pred_phi02_MPP = reg_MPP.predict(X_in_reg_MPP) 

    print('________________________________________________')
    print(f'Training_iMPP_data R^2\t={r2_score(D_in_phi02, D_pred_phi02_data):.4f}')
    train_scores_iMPP_data.append(r2_score(D_in_phi02, D_pred_phi02_data))
    
    print(f'Training_iMPP_kkddee R^2\t={r2_score(D_in_phi02, D_pred_phi02_kkddee):.4f}')
    train_scores_iMPP_kkddee.append(r2_score(D_in_phi02, D_pred_phi02_kkddee))    
    
    print(f'Training_MPP R^2\t={r2_score(D_in_phi02, D_pred_phi02_MPP):.4f}\n')
    train_scores_MPP.append(r2_score(D_in_phi02, D_pred_phi02_MPP))

    # Testing _______________________________________________________________
    X = X_test_phi02

    F_l_data = np.zeros((X.shape[0], 0))
    F_h_data = np.zeros((X.shape[0], 0))
    
    F_l_kkddee = np.zeros((X.shape[0], 0))
    F_h_kkddee = np.zeros((X.shape[0], 0))

    F_l_MPP = np.zeros((X.shape[0], 0))
    F_h_MPP = np.zeros((X.shape[0], 0))

    for j in range(0, num_p_incl):
         F_l_kkddee = np.append(F_l_kkddee, (
             a1*(kde_phi01[0]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ])) +\
             a2*(kde_phi04[0]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ]))
                              ).reshape(-1,1), axis=1)
         F_h_kkddee = np.append(F_h_kkddee, (
             a1*(kde_phi01[1]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ])) +\
             a2*(kde_phi04[1]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ]))
                              ).reshape(-1,1), axis=1)

         F_l_data = np.append(F_l_data, kde_combined[0]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ]).reshape(-1,1), axis=1)
         F_h_data = np.append(F_h_data, kde_combined[1]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ]).reshape(-1,1), axis=1)             

         F_l_MPP = np.append(F_l_MPP, kde_phi02_MPP[0]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ]).reshape(-1,1), axis=1)
         F_h_MPP = np.append(F_h_MPP, kde_phi02_MPP[1]([ X[:, 3*j], X[:, 3*j+1], X[:, 3*j+2] ]).reshape(-1,1), axis=1) 

    #V_in_phi02 = X[:, -3:]
    
    #X_in_reg = np.hstack((F_l, F_h, V_in_phi02))
    X_in_reg_data = np.hstack((F_l_data, F_h_data))
    X_in_reg_kkddee = np.hstack((F_l_kkddee, F_h_kkddee))
    X_in_reg_MPP = np.hstack((F_l_MPP, F_h_MPP))
    
    D_pred_test_data = reg_data.predict(X_in_reg_data)
    D_pred_test_kkddee = reg_data.predict(X_in_reg_kkddee)
    D_pred_test_MPP = reg_MPP.predict(X_in_reg_MPP)
    
    #print('________________________________________________')
    print(f'Test_iMPP_data R^2\t={r2_score(Y_test_phi02, D_pred_test_data):.4f}')
    test_scores_iMPP_data.append(r2_score(Y_test_phi02, D_pred_test_data))
    
    print(f'Test_iMPP_kkddee R^2\t={r2_score(Y_test_phi02, D_pred_test_kkddee):.4f}')
    test_scores_iMPP_kkddee.append(r2_score(Y_test_phi02, D_pred_test_kkddee))
    
    print(f'Test_MPP R^2\t={r2_score(Y_test_phi02, D_pred_test_MPP):.4f}')
    test_scores_MPP.append(r2_score(Y_test_phi02, D_pred_test_MPP))

    # dataset for plotting all the tests together
    #X_test_plot = np.vstack((X_test_plot, X_test_phi02))
    D_test_plot = np.concatenate((D_test_plot, Y_test_phi02))
    
    D_pred_plot_data = np.concatenate((D_pred_plot_data, D_pred_test_data))
    D_pred_plot_kkddee = np.concatenate((D_pred_plot_kkddee, D_pred_test_kkddee))      
    D_pred_plot_MPP = np.concatenate((D_pred_plot_MPP, D_pred_test_MPP))
    
    C_coefficients_data += reg_data.coef_
    C_coefficients_kkddee += reg_kkddee.coef_
    C_coefficients_MPP += reg_MPP.coef_

np.savetxt("delta_Fy_DNS", D_test_plot)
np.savetxt("delta_Fy_iMPP_data", D_pred_plot_data)
np.savetxt("delta_Fy_iMPP_kkddee", D_pred_plot_kkddee)
np.savetxt("delta_Fy_MPP", D_pred_plot_MPP)

C_coefficients_data=C_coefficients_data/n
np.savetxt("C_coefficients_iMPP_data", C_coefficients_data)
print('Averaging C_coefficients_iMPP_data________________________________________')    
print(C_coefficients_data)

C_coefficients_kkddee=C_coefficients_kkddee/n
np.savetxt("C_coefficients_iMPP_kkddee", C_coefficients_kkddee)
print('Averaging C_coefficients_iMPP_kkddee________________________________________')    
print(C_coefficients_kkddee)   

C_coefficients_MPP=C_coefficients_MPP/n
np.savetxt("C_coefficients_MPP", C_coefficients_MPP)
print('Averaging C_coefficients_MPP________________________________________')    
print(C_coefficients_MPP)  

print('________________________________________') 
print(f'<Training_iMPP_data R^2>={np.mean(train_scores_iMPP_data):.4f}')
print(f'<Test_iMPP_data R^2> = {np.mean(test_scores_iMPP_data):.4f}\n')

print('________________________________________') 
print(f'<Training_iMPP_kkddee R^2>={np.mean(train_scores_iMPP_kkddee):.4f}')
print(f'<Test_iMPP_kkddee R^2> = {np.mean(test_scores_iMPP_kkddee):.4f}\n')

print('________________________________________') 
print(f'<Training_MPP R^2>={np.mean(train_scores_MPP):.4f}')
print(f'<Test_MPP R^2> = {np.mean(test_scores_MPP):.4f}')




#******************************************************************************
#******************************************************************************###################
def plot_PDF(x1, x2, ff, title=None, savefig=True):
    '''
    This function plots the contour of the PDFs according to a
    meshgrid and values of contour.
    '''
    
    # Plot using stats KDE _________________________________________
    fig, ax1 = plt.subplots(figsize=(4, 4), tight_layout=True)
    
    mid_plane = int(grid_n.imag / 2)
    
    contour = ax1.contourf(x1[:, :, mid_plane], x2[:, :, mid_plane],
                            np.reshape(ff, x1.shape)[:, :, mid_plane],
                            cmap='jet',
                            levels=np.linspace(0, ff.max(), 20), extend='both',
                            zorder=0)

#     contour = ax1.contourf(x1[mid_plane, :, :], x2[mid_plane, :, :],
#                             np.reshape(ff, x1.shape)[mid_plane, :, :],
#                             cmap='jet',
#                             levels=np.linspace(0, ff.max(), 30), extend='both',
#                             zorder=0)

    circ1 = plt.Circle((0,0), radius=0.5,
                       alpha=1,
                       facecolor='none',
                       edgecolor='black',
                       linewidth=2,
                       zorder=2)
    ax1.add_patch(circ1)

    ax1.set_aspect('equal')

    ax1.set_xticks(range(-4,5,1))
    ax1.set_yticks(range(-4,5,1))

    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator)
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=4)

    ax1.set_xlabel('$ x $')
    ax1.set_ylabel('$ y $')
    
    if title != None:
        ax1.set_title(title, fontsize=20)
        
#         ax1.set_title(r'$ \tilde{p} \left( \cup_{j=1}^' +\
#                       f'{num_p_incl}' +\
#                       r'\mathbf{r}_j \: \vert \: \Delta F_x > 0 \right) $', fontsize=17)
#         ax1.set_title(r'$ \tilde{p}_1 \left( \mathbf{r}_{' + f'{num_p_incl}' + r'} \: \vert \: \Delta T_z < -\sigma \right) $')

    ax1.vlines(x=0, ymin=yy.min(), ymax=yy.max(), color='white', linewidth=0.75, zorder=1)
    ax1.hlines(y=0, xmin=xx.min(), xmax=xx.max(), color='white', linewidth=0.75, zorder=1)

    # Color bar________________________________
    from mpl_toolkits.axes_grid1 import make_axes_locatable
    divider = make_axes_locatable(ax1)
    cax = divider.append_axes('right', size='5%', pad=0.2)
    cb = fig.colorbar(contour, cax=cax, format='%.3f', extendrect=True)

    from matplotlib.ticker import FormatStrFormatter
    cb.ax.tick_params(labelsize=14)

    for l in cb.ax.yaxis.get_ticklabels():
        l.set_family('Times New Roman')

    # Set the font name for axis tick labels______________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')

    # remove white lines separating the contours_______________
    for c in contour.collections:
        c.set_edgecolor('face')

    # Adjust number of ticks in colorbar
    from matplotlib import ticker
    tick_locator = ticker.MaxNLocator(nbins=6)
    cb.locator = tick_locator
    cb.update_ticks()
    
    if savefig:
        fig.savefig('Fy_phi01_Re63_iMPP_data-1.pdf', bbox_inches='tight')#***************************************************

#Visual comparison between true and interpolated PDFs for  𝜙=0.2
import matplotlib.pyplot as plt
levels = 20
lim = 4

grid_n = 30j

xx, yy, zz = np.mgrid[-lim:lim:grid_n, -lim:lim:grid_n, -lim:lim:grid_n]
mesh = np.vstack([xx.flatten(), yy.flatten(), zz.flatten()])

ff = np.reshape(kde_combined[1](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.01 & 0.1 $', savefig=True)
plot_PDF(xx, yy, ff, savefig=True)







#******************************************************************************
#******************************************************************************
def plot_PDF(x1, x2, ff, title=None, savefig=True):
    '''
    This function plots the contour of the PDFs according to a
    meshgrid and values of contour.
    '''
    
    # Plot using stats KDE _________________________________________
    fig, ax1 = plt.subplots(figsize=(4, 4), tight_layout=True)
    
    mid_plane = int(grid_n.imag / 2)
    
    contour = ax1.contourf(x1[:, :, mid_plane], x2[:, :, mid_plane],
                            np.reshape(ff, x1.shape)[:, :, mid_plane],
                            cmap='jet',
                            levels=np.linspace(0, ff.max(), 20), extend='both',
                            zorder=0)

#     contour = ax1.contourf(x1[mid_plane, :, :], x2[mid_plane, :, :],
#                             np.reshape(ff, x1.shape)[mid_plane, :, :],
#                             cmap='jet',
#                             levels=np.linspace(0, ff.max(), 30), extend='both',
#                             zorder=0)

    circ1 = plt.Circle((0,0), radius=0.5,
                       alpha=1,
                       facecolor='none',
                       edgecolor='black',
                       linewidth=2,
                       zorder=2)
    ax1.add_patch(circ1)

    ax1.set_aspect('equal')

    ax1.set_xticks(range(-4,5,1))
    ax1.set_yticks(range(-4,5,1))

    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator)
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=4)

    ax1.set_xlabel('$ x $')
    ax1.set_ylabel('$ y $')
    
    if title != None:
        ax1.set_title(title, fontsize=20)
        
#         ax1.set_title(r'$ \tilde{p} \left( \cup_{j=1}^' +\
#                       f'{num_p_incl}' +\
#                       r'\mathbf{r}_j \: \vert \: \Delta F_x > 0 \right) $', fontsize=17)
#         ax1.set_title(r'$ \tilde{p}_1 \left( \mathbf{r}_{' + f'{num_p_incl}' + r'} \: \vert \: \Delta T_z < -\sigma \right) $')

    ax1.vlines(x=0, ymin=yy.min(), ymax=yy.max(), color='white', linewidth=0.75, zorder=1)
    ax1.hlines(y=0, xmin=xx.min(), xmax=xx.max(), color='white', linewidth=0.75, zorder=1)

    # Color bar________________________________
    from mpl_toolkits.axes_grid1 import make_axes_locatable
    divider = make_axes_locatable(ax1)
    cax = divider.append_axes('right', size='5%', pad=0.2)
    cb = fig.colorbar(contour, cax=cax, format='%.3f', extendrect=True)

    from matplotlib.ticker import FormatStrFormatter
    cb.ax.tick_params(labelsize=14)

    for l in cb.ax.yaxis.get_ticklabels():
        l.set_family('Times New Roman')

    # Set the font name for axis tick labels______________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')

    # remove white lines separating the contours_______________
    for c in contour.collections:
        c.set_edgecolor('face')

    # Adjust number of ticks in colorbar
    from matplotlib import ticker
    tick_locator = ticker.MaxNLocator(nbins=6)
    cb.locator = tick_locator
    cb.update_ticks()
    
    if savefig:
        fig.savefig('Fy_phi01_Re63_iMPP_data-0.pdf', bbox_inches='tight')#***************************************************

#Visual comparison between true and interpolated PDFs for  𝜙=0.2
import matplotlib.pyplot as plt
levels = 20
lim = 4

grid_n = 30j

xx, yy, zz = np.mgrid[-lim:lim:grid_n, -lim:lim:grid_n, -lim:lim:grid_n]
mesh = np.vstack([xx.flatten(), yy.flatten(), zz.flatten()])

ff = np.reshape(kde_combined[0](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi =  0.01 & 0.1 $', savefig=True)
plot_PDF(xx, yy, ff, savefig=True)

#ff = np.reshape(kde_phi02[1](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.07 $')
#plot_PDF(xx, yy, ff, title='$ \phi = 0.01 & 0.1 $', savefig=True)

#ff = np.reshape(kde_phi04[1](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.1 $', savefig=True)

#ff = np.reshape(kde_phi01[0](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.01 $', savefig=True)

#ff = np.reshape(kde_phi02[0](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.07 $')
#plot_PDF(xx, yy, ff, title='$ \phi = 0.01 & 0.1 $', savefig=True)

#ff = np.reshape(kde_phi04[0](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.1 $', savefig=True)

#******************************************************************************




#******************************************************************************
#******************************************************************************################### Map
def plot_PDF(x1, x2, ff, title=None, savefig=True):
    '''
    This function plots the contour of the PDFs according to a
    meshgrid and values of contour.
    '''
    
    # Plot using stats KDE _________________________________________
    fig, ax1 = plt.subplots(figsize=(4, 4), tight_layout=True)
    
    mid_plane = int(grid_n.imag / 2)
    
    contour = ax1.contourf(x1[:, :, mid_plane], x2[:, :, mid_plane],
                            np.reshape(ff, x1.shape)[:, :, mid_plane],
                            cmap='jet',
                            levels=np.linspace(0, ff.max(), 20), extend='both',
                            zorder=0)

#     contour = ax1.contourf(x1[mid_plane, :, :], x2[mid_plane, :, :],
#                             np.reshape(ff, x1.shape)[mid_plane, :, :],
#                             cmap='jet',
#                             levels=np.linspace(0, ff.max(), 30), extend='both',
#                             zorder=0)

    circ1 = plt.Circle((0,0), radius=0.5,
                       alpha=1,
                       facecolor='none',
                       edgecolor='black',
                       linewidth=2,
                       zorder=2)
    ax1.add_patch(circ1)

    ax1.set_aspect('equal')

    ax1.set_xticks(range(-4,5,1))
    ax1.set_yticks(range(-4,5,1))

    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator)
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=4)

    ax1.set_xlabel('$ x $')
    ax1.set_ylabel('$ y $')
    
    if title != None:
        ax1.set_title(title, fontsize=20)
        
#         ax1.set_title(r'$ \tilde{p} \left( \cup_{j=1}^' +\
#                       f'{num_p_incl}' +\
#                       r'\mathbf{r}_j \: \vert \: \Delta F_x > 0 \right) $', fontsize=17)
#         ax1.set_title(r'$ \tilde{p}_1 \left( \mathbf{r}_{' + f'{num_p_incl}' + r'} \: \vert \: \Delta T_z < -\sigma \right) $')

    ax1.vlines(x=0, ymin=yy.min(), ymax=yy.max(), color='white', linewidth=0.75, zorder=1)
    ax1.hlines(y=0, xmin=xx.min(), xmax=xx.max(), color='white', linewidth=0.75, zorder=1)

    # Color bar________________________________
    from mpl_toolkits.axes_grid1 import make_axes_locatable
    divider = make_axes_locatable(ax1)
    cax = divider.append_axes('right', size='5%', pad=0.2)
    cb = fig.colorbar(contour, cax=cax, format='%.3f', extendrect=True)

    from matplotlib.ticker import FormatStrFormatter
    cb.ax.tick_params(labelsize=14)

    for l in cb.ax.yaxis.get_ticklabels():
        l.set_family('Times New Roman')

    # Set the font name for axis tick labels______________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')

    # remove white lines separating the contours_______________
    for c in contour.collections:
        c.set_edgecolor('face')

    # Adjust number of ticks in colorbar
    from matplotlib import ticker
    tick_locator = ticker.MaxNLocator(nbins=6)
    cb.locator = tick_locator
    cb.update_ticks()
    
    if savefig:
        fig.savefig('Fy_phi01_Re63-1.pdf', bbox_inches='tight')#***************************************************

#Visual comparison between true and interpolated PDFs for  𝜙=0.2
import matplotlib.pyplot as plt
levels = 20
lim = 4

grid_n = 30j

xx, yy, zz = np.mgrid[-lim:lim:grid_n, -lim:lim:grid_n, -lim:lim:grid_n]
mesh = np.vstack([xx.flatten(), yy.flatten(), zz.flatten()])

ff = np.reshape(kde_phi01[1](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.01 & 0.1 $', savefig=True)
plot_PDF(xx, yy, ff, savefig=True)




#******************************************************************************
#******************************************************************************################### Map
def plot_PDF(x1, x2, ff, title=None, savefig=True):
    '''
    This function plots the contour of the PDFs according to a
    meshgrid and values of contour.
    '''
    
    # Plot using stats KDE _________________________________________
    fig, ax1 = plt.subplots(figsize=(4, 4), tight_layout=True)
    
    mid_plane = int(grid_n.imag / 2)
    
    contour = ax1.contourf(x1[:, :, mid_plane], x2[:, :, mid_plane],
                            np.reshape(ff, x1.shape)[:, :, mid_plane],
                            cmap='jet',
                            levels=np.linspace(0, ff.max(), 20), extend='both',
                            zorder=0)

#     contour = ax1.contourf(x1[mid_plane, :, :], x2[mid_plane, :, :],
#                             np.reshape(ff, x1.shape)[mid_plane, :, :],
#                             cmap='jet',
#                             levels=np.linspace(0, ff.max(), 30), extend='both',
#                             zorder=0)

    circ1 = plt.Circle((0,0), radius=0.5,
                       alpha=1,
                       facecolor='none',
                       edgecolor='black',
                       linewidth=2,
                       zorder=2)
    ax1.add_patch(circ1)

    ax1.set_aspect('equal')

    ax1.set_xticks(range(-4,5,1))
    ax1.set_yticks(range(-4,5,1))

    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator)
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=4)

    ax1.set_xlabel('$ x $')
    ax1.set_ylabel('$ y $')
    
    if title != None:
        ax1.set_title(title, fontsize=20)
        
#         ax1.set_title(r'$ \tilde{p} \left( \cup_{j=1}^' +\
#                       f'{num_p_incl}' +\
#                       r'\mathbf{r}_j \: \vert \: \Delta F_x > 0 \right) $', fontsize=17)
#         ax1.set_title(r'$ \tilde{p}_1 \left( \mathbf{r}_{' + f'{num_p_incl}' + r'} \: \vert \: \Delta T_z < -\sigma \right) $')

    ax1.vlines(x=0, ymin=yy.min(), ymax=yy.max(), color='white', linewidth=0.75, zorder=1)
    ax1.hlines(y=0, xmin=xx.min(), xmax=xx.max(), color='white', linewidth=0.75, zorder=1)

    # Color bar________________________________
    from mpl_toolkits.axes_grid1 import make_axes_locatable
    divider = make_axes_locatable(ax1)
    cax = divider.append_axes('right', size='5%', pad=0.2)
    cb = fig.colorbar(contour, cax=cax, format='%.3f', extendrect=True)

    from matplotlib.ticker import FormatStrFormatter
    cb.ax.tick_params(labelsize=14)

    for l in cb.ax.yaxis.get_ticklabels():
        l.set_family('Times New Roman')

    # Set the font name for axis tick labels______________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')

    # remove white lines separating the contours_______________
    for c in contour.collections:
        c.set_edgecolor('face')

    # Adjust number of ticks in colorbar
    from matplotlib import ticker
    tick_locator = ticker.MaxNLocator(nbins=6)
    cb.locator = tick_locator
    cb.update_ticks()
    
    if savefig:
        fig.savefig('Fy_phi01_Re63-0.pdf', bbox_inches='tight')#***************************************************

#Visual comparison between true and interpolated PDFs for  𝜙=0.2
import matplotlib.pyplot as plt
levels = 20
lim = 4

grid_n = 30j

xx, yy, zz = np.mgrid[-lim:lim:grid_n, -lim:lim:grid_n, -lim:lim:grid_n]
mesh = np.vstack([xx.flatten(), yy.flatten(), zz.flatten()])

ff = np.reshape(kde_phi01[0](mesh).T, xx.shape)
#plot_PDF(xx, yy, ff, title='$ \phi = 0.01 & 0.1 $', savefig=True)
plot_PDF(xx, yy, ff, savefig=True)










# plotting _______________________________________________________________________Combined data
def plot_regression(D_in, D_pred, coord=None, title=None, save_fig=True):
    
    plt.rcParams['xtick.labelsize'] = 16
    plt.rcParams['ytick.labelsize'] = 16
    plt.rcParams['axes.labelsize'] = 22
    plt.rcParams['axes.titlesize'] = 14

    # generate the best fit for the predicted data ___________________
    lim1 = np.mean(D_in) - 3.5*np.std(D_in)
    lim2 = np.mean(D_in) + 3.5*np.std(D_in)
    lim3 = np.mean(D_pred) - 2*np.std(D_pred)

    reg2 = LinearRegression()
    reg2.fit(D_in.reshape(-1,1), D_pred.reshape(-1,1))
    D_vec = np.linspace(lim1, lim2, 100).reshape(-1,1)
    D_reg2 = reg2.predict(D_vec)
    
    # Plots _____________________
    fig, ax1 = plt.subplots(figsize=(4,4), tight_layout=True)
    
    ax1.scatter(D_in, D_pred,
                marker='o',
                s=10, linewidth=0.4,
                alpha=0.5,
                edgecolor='blue', facecolor='white')
    ax1.plot([lim1, lim2], [lim1, lim2], linestyle='-', color='red', linewidth=2.5, alpha=0.3)
#     ax1.plot(D_vec, D_reg2, linestyle='-', color='black', linewidth=2.5, alpha=0.1)
    
    ax1.set_aspect('equal')
    
    if coord != None:
        if coord == 'F_x':
            ax1.set_xlabel('$\Delta F_{x,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{x,iMPP-data}$', labelpad=10)
        elif coord == 'F_y':
            ax1.set_xlabel('$\Delta F_{y,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{y,iMPP-data}$', labelpad=10)
        elif coord == 'T_z':
            ax1.set_xlabel('$\Delta T_{z,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta T_{z,iMPP-data}$', labelpad=10)
    
    ax1.set_xlim((1.0*lim1, 1.0*lim2))
    ax1.set_ylim((1.0*lim1, 1.0*lim2))

    #     ax1.set_xticks(range(-4,5,1))
    #     ax1.set_yticks(range(-4,5,1))

    # R^2 on plot _____________________
    x_ann = ax1.get_xlim()[1] - 0.05*(plt.xlim()[1]-plt.xlim()[0])
    y_ann = ax1.get_ylim()[0] + 0.05*(plt.ylim()[1]-plt.ylim()[0])
    ax1.annotate(str(r'$\mathrm{R^2} = ' + f'{r2_score(D_in, D_pred):.4f}$'), 
                 xy=(x_ann, y_ann),
                 horizontalalignment='right',
                 verticalalignment='bottom',
                 fontsize=18);

    # ticks _____________________
    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator, MaxNLocator)
    
    ax1.xaxis.set_major_locator(MaxNLocator(5))
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.yaxis.set_major_locator(MaxNLocator(5))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=2)
    
    # Set the font name for axis tick labels _____________________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')
        
    if title != None:
        ax1.set_title(title)
        
    if save_fig:
        fig.savefig('R2_Fy_phi01_Re63_iMPP-data_DNS.pdf', bbox_inches='tight')#***************************************************
    
    return None

#plot_regression(coord=coord, title=title, save_fig=True)
import matplotlib.pyplot as plt
plot_regression(D_in=D_test_plot, D_pred=D_pred_plot_data, coord=coord, title=title, save_fig=True)


#*****************************************************************************
#Coefficients
#plt.plot(reg.coef_, linewidth=0, marker='.', color='red', markersize=10)
#plt.grid()




########################################################################################################################
# plotting _______________________________________________________________________Combined data
def plot_regression(D_in, D_pred, coord=None, title=None, save_fig=True):
    
    plt.rcParams['xtick.labelsize'] = 16
    plt.rcParams['ytick.labelsize'] = 16
    plt.rcParams['axes.labelsize'] = 22
    plt.rcParams['axes.titlesize'] = 14

    # generate the best fit for the predicted data ___________________
    lim1 = np.mean(D_in) - 3.5*np.std(D_in)
    lim2 = np.mean(D_in) + 3.5*np.std(D_in)
    lim3 = np.mean(D_pred) - 2*np.std(D_pred)

    reg2 = LinearRegression()
    reg2.fit(D_in.reshape(-1,1), D_pred.reshape(-1,1))
    D_vec = np.linspace(lim1, lim2, 100).reshape(-1,1)
    D_reg2 = reg2.predict(D_vec)
    
    # Plots _____________________
    fig, ax1 = plt.subplots(figsize=(4,4), tight_layout=True)
    
    ax1.scatter(D_in, D_pred,
                marker='o',
                s=10, linewidth=0.4,
                alpha=0.5,
                edgecolor='blue', facecolor='white')
    ax1.plot([lim1, lim2], [lim1, lim2], linestyle='-', color='red', linewidth=2.5, alpha=0.3)
#     ax1.plot(D_vec, D_reg2, linestyle='-', color='black', linewidth=2.5, alpha=0.1)
    
    ax1.set_aspect('equal')
    
    if coord != None:
        if coord == 'F_x':
            ax1.set_xlabel('$\Delta F_{x,MPP}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{x,iMPP-data}$', labelpad=10)
        elif coord == 'F_y':
            ax1.set_xlabel('$\Delta F_{y,MPP}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{y,iMPP-data}$', labelpad=10)
        elif coord == 'T_z':
            ax1.set_xlabel('$\Delta T_{z,MPP}$', labelpad=15)
            ax1.set_ylabel('$\Delta T_{z,iMPP-data}$', labelpad=10)
    
    ax1.set_xlim((1.0*lim1, 1.0*lim2))
    ax1.set_ylim((1.0*lim1, 1.0*lim2))

    #     ax1.set_xticks(range(-4,5,1))
    #     ax1.set_yticks(range(-4,5,1))

    # R^2 on plot _____________________
    x_ann = ax1.get_xlim()[1] - 0.05*(plt.xlim()[1]-plt.xlim()[0])
    y_ann = ax1.get_ylim()[0] + 0.05*(plt.ylim()[1]-plt.ylim()[0])
    ax1.annotate(str(r'$\mathrm{R^2} = ' + f'{r2_score(D_in, D_pred):.4f}$'), 
                 xy=(x_ann, y_ann),
                 horizontalalignment='right',
                 verticalalignment='bottom',
                 fontsize=18);

    # ticks _____________________
    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator, MaxNLocator)
    
    ax1.xaxis.set_major_locator(MaxNLocator(5))
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.yaxis.set_major_locator(MaxNLocator(5))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=2)
    
    # Set the font name for axis tick labels _____________________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')
        
    if title != None:
        ax1.set_title(title)
        
    if save_fig:
        fig.savefig('R2_Fy_phi01_Re63_iMPP-data_MPP.pdf', bbox_inches='tight')#***************************************************
    
    return None

#plot_regression(coord=coord, title=title, save_fig=True)
import matplotlib.pyplot as plt
plot_regression(D_in=D_pred_plot_MPP, D_pred=D_pred_plot_data, coord=coord, title=title, save_fig=True)

#*****************************************************************************



# plotting _______________________________________________________________________KDE
def plot_regression(D_in, D_pred, coord=None, title=None, save_fig=True):
    
    plt.rcParams['xtick.labelsize'] = 16
    plt.rcParams['ytick.labelsize'] = 16
    plt.rcParams['axes.labelsize'] = 22
    plt.rcParams['axes.titlesize'] = 14

    # generate the best fit for the predicted data ___________________
    lim1 = np.mean(D_in) - 3.5*np.std(D_in)
    lim2 = np.mean(D_in) + 3.5*np.std(D_in)
    lim3 = np.mean(D_pred) - 2*np.std(D_pred)

    reg2 = LinearRegression()
    reg2.fit(D_in.reshape(-1,1), D_pred.reshape(-1,1))
    D_vec = np.linspace(lim1, lim2, 100).reshape(-1,1)
    D_reg2 = reg2.predict(D_vec)
    
    # Plots _____________________
    fig, ax1 = plt.subplots(figsize=(4,4), tight_layout=True)
    
    ax1.scatter(D_in, D_pred,
                marker='o',
                s=10, linewidth=0.4,
                alpha=0.5,
                edgecolor='blue', facecolor='white')
    ax1.plot([lim1, lim2], [lim1, lim2], linestyle='-', color='red', linewidth=2.5, alpha=0.3)
#     ax1.plot(D_vec, D_reg2, linestyle='-', color='black', linewidth=2.5, alpha=0.1)
    
    ax1.set_aspect('equal')
    
    if coord != None:
        if coord == 'F_x':
            ax1.set_xlabel('$\Delta F_{x,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{x,iMPP-KDE}$', labelpad=10)
        elif coord == 'F_y':
            ax1.set_xlabel('$\Delta F_{y,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{y,iMPP-KDE}$', labelpad=10)
        elif coord == 'T_z':
            ax1.set_xlabel('$\Delta T_{z,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta T_{z,iMPP-KDE}$', labelpad=10)
    
    ax1.set_xlim((1.0*lim1, 1.0*lim2))
    ax1.set_ylim((1.0*lim1, 1.0*lim2))

    #     ax1.set_xticks(range(-4,5,1))
    #     ax1.set_yticks(range(-4,5,1))

    # R^2 on plot _____________________
    x_ann = ax1.get_xlim()[1] - 0.05*(plt.xlim()[1]-plt.xlim()[0])
    y_ann = ax1.get_ylim()[0] + 0.05*(plt.ylim()[1]-plt.ylim()[0])
    ax1.annotate(str(r'$\mathrm{R^2} = ' + f'{r2_score(D_in, D_pred):.4f}$'), 
                 xy=(x_ann, y_ann),
                 horizontalalignment='right',
                 verticalalignment='bottom',
                 fontsize=18);

    # ticks _____________________
    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator, MaxNLocator)
    
    ax1.xaxis.set_major_locator(MaxNLocator(5))
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.yaxis.set_major_locator(MaxNLocator(5))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=2)
    
    # Set the font name for axis tick labels _____________________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')
        
    if title != None:
        ax1.set_title(title)
        
    if save_fig:
        fig.savefig('R2_Fy_phi01_Re63_iMPP-KDE_DNS.pdf', bbox_inches='tight')#***************************************************
    
    return None

#plot_regression(coord=coord, title=title, save_fig=True)
import matplotlib.pyplot as plt
plot_regression(D_in=D_test_plot, D_pred=D_pred_plot_kkddee, coord=coord, title=title, save_fig=True)



########################################################################################################################
# plotting _______________________________________________________________________KDE
def plot_regression(D_in, D_pred, coord=None, title=None, save_fig=True):
    
    plt.rcParams['xtick.labelsize'] = 16
    plt.rcParams['ytick.labelsize'] = 16
    plt.rcParams['axes.labelsize'] = 22
    plt.rcParams['axes.titlesize'] = 14

    # generate the best fit for the predicted data ___________________
    lim1 = np.mean(D_in) - 3.5*np.std(D_in)
    lim2 = np.mean(D_in) + 3.5*np.std(D_in)
    lim3 = np.mean(D_pred) - 2*np.std(D_pred)

    reg2 = LinearRegression()
    reg2.fit(D_in.reshape(-1,1), D_pred.reshape(-1,1))
    D_vec = np.linspace(lim1, lim2, 100).reshape(-1,1)
    D_reg2 = reg2.predict(D_vec)
    
    # Plots _____________________
    fig, ax1 = plt.subplots(figsize=(4,4), tight_layout=True)
    
    ax1.scatter(D_in, D_pred,
                marker='o',
                s=10, linewidth=0.4,
                alpha=0.5,
                edgecolor='blue', facecolor='white')
    ax1.plot([lim1, lim2], [lim1, lim2], linestyle='-', color='red', linewidth=2.5, alpha=0.3)
#     ax1.plot(D_vec, D_reg2, linestyle='-', color='black', linewidth=2.5, alpha=0.1)
    
    ax1.set_aspect('equal')
    
    if coord != None:
        if coord == 'F_x':
            ax1.set_xlabel('$\Delta F_{x,MPP}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{x,iMPP-KDE}$', labelpad=10)
        elif coord == 'F_y':
            ax1.set_xlabel('$\Delta F_{y,MPP}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{y,iMPP-KDE}$', labelpad=10)
        elif coord == 'T_z':
            ax1.set_xlabel('$\Delta T_{z,MPP}$', labelpad=15)
            ax1.set_ylabel('$\Delta T_{z,iMPP-KDE}$', labelpad=10)
    
    ax1.set_xlim((1.0*lim1, 1.0*lim2))
    ax1.set_ylim((1.0*lim1, 1.0*lim2))

    #     ax1.set_xticks(range(-4,5,1))
    #     ax1.set_yticks(range(-4,5,1))

    # R^2 on plot _____________________
    x_ann = ax1.get_xlim()[1] - 0.05*(plt.xlim()[1]-plt.xlim()[0])
    y_ann = ax1.get_ylim()[0] + 0.05*(plt.ylim()[1]-plt.ylim()[0])
    ax1.annotate(str(r'$\mathrm{R^2} = ' + f'{r2_score(D_in, D_pred):.4f}$'), 
                 xy=(x_ann, y_ann),
                 horizontalalignment='right',
                 verticalalignment='bottom',
                 fontsize=18);

    # ticks _____________________
    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator, MaxNLocator)
    
    ax1.xaxis.set_major_locator(MaxNLocator(5))
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.yaxis.set_major_locator(MaxNLocator(5))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=2)
    
    # Set the font name for axis tick labels _____________________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')
        
    if title != None:
        ax1.set_title(title)
        
    if save_fig:
        fig.savefig('R2_Fy_phi01_Re63_iMPP-KDE_MPP.pdf', bbox_inches='tight')#***************************************************
    
    return None

#plot_regression(coord=coord, title=title, save_fig=True)
import matplotlib.pyplot as plt
plot_regression(D_in=D_pred_plot_MPP, D_pred=D_pred_plot_kkddee, coord=coord, title=title, save_fig=True)

#*****************************************************************************



# plotting _______________________________________________________________________
def plot_regression(D_in, D_pred, coord=None, title=None, save_fig=True):
    
    plt.rcParams['xtick.labelsize'] = 16
    plt.rcParams['ytick.labelsize'] = 16
    plt.rcParams['axes.labelsize'] = 22
    plt.rcParams['axes.titlesize'] = 14

    # generate the best fit for the predicted data ___________________
    lim1 = np.mean(D_in) - 3.5*np.std(D_in)
    lim2 = np.mean(D_in) + 3.5*np.std(D_in)
    lim3 = np.mean(D_pred) - 2*np.std(D_pred)

    reg2 = LinearRegression()
    reg2.fit(D_in.reshape(-1,1), D_pred.reshape(-1,1))
    D_vec = np.linspace(lim1, lim2, 100).reshape(-1,1)
    D_reg2 = reg2.predict(D_vec)
    
    # Plots _____________________
    fig, ax1 = plt.subplots(figsize=(4,4), tight_layout=True)
    
    ax1.scatter(D_in, D_pred,
                marker='o',
                s=10, linewidth=0.4,
                alpha=0.5,
                edgecolor='blue', facecolor='white')
    ax1.plot([lim1, lim2], [lim1, lim2], linestyle='-', color='red', linewidth=2.5, alpha=0.3)
#     ax1.plot(D_vec, D_reg2, linestyle='-', color='black', linewidth=2.5, alpha=0.1)
    
    ax1.set_aspect('equal')
    
    if coord != None:
        if coord == 'F_x':
            ax1.set_xlabel('$\Delta F_{x,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{x,MPP}$', labelpad=10)
        elif coord == 'F_y':
            ax1.set_xlabel('$\Delta F_{y,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta F_{y,MPP}$', labelpad=10)
        elif coord == 'T_z':
            ax1.set_xlabel('$\Delta T_{z,DNS}$', labelpad=15)
            ax1.set_ylabel('$\Delta T_{z,MPP}$', labelpad=10)
    
    ax1.set_xlim((1.0*lim1, 1.0*lim2))
    ax1.set_ylim((1.0*lim1, 1.0*lim2))

    #     ax1.set_xticks(range(-4,5,1))
    #     ax1.set_yticks(range(-4,5,1))

    # R^2 on plot _____________________
    x_ann = ax1.get_xlim()[1] - 0.05*(plt.xlim()[1]-plt.xlim()[0])
    y_ann = ax1.get_ylim()[0] + 0.05*(plt.ylim()[1]-plt.ylim()[0])
    ax1.annotate(str(r'$\mathrm{R^2} = ' + f'{r2_score(D_in, D_pred):.4f}$'), 
                 xy=(x_ann, y_ann),
                 horizontalalignment='right',
                 verticalalignment='bottom',
                 fontsize=18);

    # ticks _____________________
    from matplotlib.ticker import (MultipleLocator, AutoMinorLocator, MaxNLocator)
    
    ax1.xaxis.set_major_locator(MaxNLocator(5))
    ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.yaxis.set_major_locator(MaxNLocator(5))
    ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
    
    ax1.tick_params(which='major', length=5)
    ax1.tick_params(which='minor', length=2)
    
    # Set the font name for axis tick labels _____________________
    for tick in ax1.get_xticklabels():
        tick.set_fontname('Times New Roman')
    for tick in ax1.get_yticklabels():
        tick.set_fontname('Times New Roman')
        
    if title != None:
        ax1.set_title(title)
        
    if save_fig:
        fig.savefig('R2_Fy_phi01_Re63_MPP_DNS.pdf', bbox_inches='tight')#***************************************************
    
    return None

#plot_regression(coord=coord, title=title, save_fig=True)
import matplotlib.pyplot as plt
plot_regression(D_in=D_test_plot, D_pred=D_pred_plot_MPP, coord=coord, title=title, save_fig=True)

#*****************************************************************************



