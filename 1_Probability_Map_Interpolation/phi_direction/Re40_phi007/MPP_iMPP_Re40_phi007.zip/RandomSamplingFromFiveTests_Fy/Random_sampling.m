close all; clear all; clc


delta_Fy_MPP1_a=load('delta_Fy_MPP1.txt');
delta_Fy_MPP2_a=load('delta_Fy_MPP2.txt');
delta_Fy_MPP3_a=load('delta_Fy_MPP3.txt');
delta_Fy_MPP4_a=load('delta_Fy_MPP4.txt');
delta_Fy_MPP5_a=load('delta_Fy_MPP5.txt');

delta_Fy_MPP1_N=numel(delta_Fy_MPP1_a(:,1)); %�������˳��
delta_Fy_MPP2_N=numel(delta_Fy_MPP2_a(:,1));
delta_Fy_MPP3_N=numel(delta_Fy_MPP3_a(:,1));
delta_Fy_MPP4_N=numel(delta_Fy_MPP4_a(:,1));
delta_Fy_MPP5_N=numel(delta_Fy_MPP5_a(:,1));

a1=randperm(delta_Fy_MPP1_N, 400);
a2=randperm(delta_Fy_MPP2_N, 400);
a3=randperm(delta_Fy_MPP3_N, 400);
a4=randperm(delta_Fy_MPP4_N, 400);
a5=randperm(delta_Fy_MPP5_N, 400);

%delta_Fx_MPP1_sub=delta_Fx_MPP1_a(randperm(delta_Fx_MPP1_N, 400),:);
%delta_Fx_MPP2_sub=delta_Fx_MPP2_a(randperm(delta_Fx_MPP2_N, 400),:);
%delta_Fx_MPP3_sub=delta_Fx_MPP3_a(randperm(delta_Fx_MPP3_N, 400),:);
%delta_Fx_MPP4_sub=delta_Fx_MPP4_a(randperm(delta_Fx_MPP4_N, 400),:);
%delta_Fx_MPP5_sub=delta_Fx_MPP5_a(randperm(delta_Fx_MPP5_N, 400),:);
delta_Fy_MPP1_sub=delta_Fy_MPP1_a(a1,:);
delta_Fy_MPP2_sub=delta_Fy_MPP2_a(a2,:);
delta_Fy_MPP3_sub=delta_Fy_MPP3_a(a3,:);
delta_Fy_MPP4_sub=delta_Fy_MPP4_a(a4,:);
delta_Fy_MPP5_sub=delta_Fy_MPP5_a(a5,:);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta_Fy_iMPP_data1_a=load('delta_Fy_iMPP_data1.txt');
delta_Fy_iMPP_data2_a=load('delta_Fy_iMPP_data2.txt');
delta_Fy_iMPP_data3_a=load('delta_Fy_iMPP_data3.txt');
delta_Fy_iMPP_data4_a=load('delta_Fy_iMPP_data4.txt');
delta_Fy_iMPP_data5_a=load('delta_Fy_iMPP_data5.txt');

delta_Fy_iMPP_data1_sub=delta_Fy_iMPP_data1_a(a1,:);
delta_Fy_iMPP_data2_sub=delta_Fy_iMPP_data2_a(a2,:);
delta_Fy_iMPP_data3_sub=delta_Fy_iMPP_data3_a(a3,:);
delta_Fy_iMPP_data4_sub=delta_Fy_iMPP_data4_a(a4,:);
delta_Fy_iMPP_data5_sub=delta_Fy_iMPP_data5_a(a5,:);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta_Fy_iMPP_kkddee1_a=load('delta_Fy_iMPP_kkddee1.txt');
delta_Fy_iMPP_kkddee2_a=load('delta_Fy_iMPP_kkddee2.txt');
delta_Fy_iMPP_kkddee3_a=load('delta_Fy_iMPP_kkddee3.txt');
delta_Fy_iMPP_kkddee4_a=load('delta_Fy_iMPP_kkddee4.txt');
delta_Fy_iMPP_kkddee5_a=load('delta_Fy_iMPP_kkddee5.txt');

delta_Fy_iMPP_kkddee1_sub=delta_Fy_iMPP_kkddee1_a(a1,:);
delta_Fy_iMPP_kkddee2_sub=delta_Fy_iMPP_kkddee2_a(a2,:);
delta_Fy_iMPP_kkddee3_sub=delta_Fy_iMPP_kkddee3_a(a3,:);
delta_Fy_iMPP_kkddee4_sub=delta_Fy_iMPP_kkddee4_a(a4,:);
delta_Fy_iMPP_kkddee5_sub=delta_Fy_iMPP_kkddee5_a(a5,:);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta_Fy_DNS1_a=load('delta_Fy_DNS1.txt');
delta_Fy_DNS2_a=load('delta_Fy_DNS2.txt');
delta_Fy_DNS3_a=load('delta_Fy_DNS3.txt');
delta_Fy_DNS4_a=load('delta_Fy_DNS4.txt');
delta_Fy_DNS5_a=load('delta_Fy_DNS5.txt');

%delta_Fx_DNS1_N=numel(delta_Fx_DNS1_a(:,1)); 
%delta_Fx_DNS2_N=numel(delta_Fx_DNS2_a(:,1));
%delta_Fx_DNS3_N=numel(delta_Fx_DNS3_a(:,1));
%delta_Fx_DNS4_N=numel(delta_Fx_DNS4_a(:,1)); 
%delta_Fx_DNS5_N=numel(delta_Fx_DNS5_a(:,1));

delta_Fy_DNS1_sub=delta_Fy_DNS1_a(a1,:);
delta_Fy_DNS2_sub=delta_Fy_DNS2_a(a2,:);
delta_Fy_DNS3_sub=delta_Fy_DNS3_a(a3,:);
delta_Fy_DNS4_sub=delta_Fy_DNS4_a(a4,:);
delta_Fy_DNS5_sub=delta_Fy_DNS5_a(a5,:);


delta_Fy_MPP_sub= [delta_Fy_MPP1_sub;  delta_Fy_MPP2_sub;  delta_Fy_MPP3_sub;  delta_Fy_MPP4_sub;  delta_Fy_MPP5_sub];
delta_Fy_iMPP_data_sub=[delta_Fy_iMPP_data1_sub; delta_Fy_iMPP_data2_sub; delta_Fy_iMPP_data3_sub; delta_Fy_iMPP_data4_sub; delta_Fy_iMPP_data5_sub];
delta_Fy_iMPP_kkddee_sub=[delta_Fy_iMPP_kkddee1_sub; delta_Fy_iMPP_kkddee2_sub; delta_Fy_iMPP_kkddee3_sub; delta_Fy_iMPP_kkddee4_sub; delta_Fy_iMPP_kkddee5_sub];
delta_Fy_DNS_sub= [delta_Fy_DNS1_sub;  delta_Fy_DNS2_sub;  delta_Fy_DNS3_sub;  delta_Fy_DNS4_sub;  delta_Fy_DNS5_sub];
savefile = 'delta_Fy_sub.mat';
save(savefile, 'delta_Fy_DNS_sub', 'delta_Fy_MPP_sub', 'delta_Fy_iMPP_data_sub','delta_Fy_iMPP_kkddee_sub');

